<?php

use App\Http\Controllers\Api\V1\Admin\AdminOverviewController;
use App\Http\Controllers\Api\V1\Admin\BrandController;
use App\Http\Controllers\Api\V1\Admin\CategoryController;
use App\Http\Controllers\Api\V1\Admin\CustomerController;
use App\Http\Controllers\Api\V1\Admin\InventoryAdjustmentController;
use App\Http\Controllers\Api\V1\Admin\OrderController;
use App\Http\Controllers\Api\V1\Admin\ProductAttributeController;
use App\Http\Controllers\Api\V1\Admin\ProductAttributeValueController;
use App\Http\Controllers\Api\V1\Admin\ProductController;
use App\Http\Controllers\Api\V1\Admin\ProductImageController;
use App\Http\Controllers\Api\V1\Admin\ProductPublicationController;
use App\Http\Controllers\Api\V1\Admin\ProductVariantController;
use App\Http\Controllers\Api\V1\Admin\ShippingSettingsController;
use App\Http\Controllers\Api\V1\Admin\StoreSettingsController;
use App\Http\Controllers\Api\V1\AuthController;
use App\Http\Controllers\Api\V1\CheckoutController;
use App\Http\Controllers\Api\V1\CustomerOrderController;
use App\Http\Controllers\Api\V1\PublicBrandController;
use App\Http\Controllers\Api\V1\PublicCategoryController;
use App\Http\Controllers\Api\V1\PublicProductController;
use App\Http\Controllers\Api\V1\SiteSettingsController;
use Illuminate\Support\Facades\Route;

Route::prefix('v1')->group(function (): void {
    Route::get('/health', fn () => response()->json(['data' => ['status' => 'ok']]));
    Route::get('/site-settings', SiteSettingsController::class)->middleware('throttle:60,1');
    Route::get('/categories', [PublicCategoryController::class, 'index'])->middleware('throttle:60,1');
    Route::get('/brands', [PublicBrandController::class, 'index'])->middleware('throttle:60,1');
    Route::get('/disease-tags', [PublicProductController::class, 'diseases'])->middleware('throttle:60,1');
    Route::get('/product-tags', [PublicProductController::class, 'tags'])->middleware('throttle:60,1');
    Route::get('/products', [PublicProductController::class, 'index'])->middleware('throttle:60,1')->name('public.products.index');
    Route::get('/products/{slug}', [PublicProductController::class, 'show'])->middleware('throttle:60,1')->name('public.products.show');

    Route::get('/checkout/zones', [CheckoutController::class, 'zones'])->middleware('throttle:60,1');
    Route::post('/checkout', [CheckoutController::class, 'store'])->middleware(['auth:sanctum', 'throttle:10,1,checkout-order:']);
    Route::middleware('auth:sanctum')->prefix('account')->group(function (): void {
        Route::get('/orders', [CustomerOrderController::class, 'index']);
        Route::get('/orders/{number}', [CustomerOrderController::class, 'show']);
    });

    Route::prefix('auth')->group(function (): void {
        Route::post('/register', [AuthController::class, 'register'])->middleware('throttle:5,1');
        Route::post('/login', [AuthController::class, 'login'])->middleware('throttle:5,1');
        Route::middleware('auth:sanctum')->group(function (): void {
            Route::get('/me', [AuthController::class, 'me']);
            Route::post('/logout', [AuthController::class, 'logout']);
        });
    });

    Route::prefix('admin')->group(function (): void {
        Route::post('/auth/login', [AuthController::class, 'adminLogin'])->middleware('throttle:5,1');
        Route::middleware(['auth:sanctum', 'permission:admin.access'])->group(function (): void {
            Route::get('/me', [AuthController::class, 'me']);
            Route::get('/overview', AdminOverviewController::class);
            Route::get('/customers', [CustomerController::class, 'index'])->middleware('permission:customers.view');
            Route::post('/customers', [CustomerController::class, 'store'])->middleware('permission:customers.manage');
            Route::get('/customers/{customer}/avatar', [CustomerController::class, 'avatar'])->middleware('permission:customers.view');
            Route::middleware('permission:orders.view')->group(function (): void {
                Route::get('/orders/counts', [OrderController::class, 'counts']);
                Route::get('/orders', [OrderController::class, 'index']);
                Route::get('/orders/by-public-id/{publicId}', [OrderController::class, 'showByPublicId']);
                Route::get('/orders/product-options', [OrderController::class, 'productOptions'])->middleware('permission:orders.manage');
                Route::get('/orders/{order}', [OrderController::class, 'show']);
            });
            Route::put('/orders/by-public-id/{publicId}', [OrderController::class, 'updateByPublicId'])
                ->middleware(['permission:orders.view', 'permission:orders.manage']);
            Route::put('/orders/{order}', [OrderController::class, 'update'])
                ->middleware(['permission:orders.view', 'permission:orders.manage']);
            Route::get('/shipping-zones', [ShippingSettingsController::class, 'show'])->middleware('permission:settings.view');
            Route::put('/shipping-zones', [ShippingSettingsController::class, 'update'])->middleware('permission:settings.manage');
            Route::get('/settings', [StoreSettingsController::class, 'show'])->middleware('permission:settings.view');
            Route::put('/settings', [StoreSettingsController::class, 'update'])
                ->middleware(['permission:settings.view', 'permission:settings.manage']);

            Route::middleware('permission:catalog.view')->group(function (): void {
                Route::get('/categories', [CategoryController::class, 'index']);
                Route::get('/categories/{category}', [CategoryController::class, 'show']);
                Route::get('/brands', [BrandController::class, 'index']);
                Route::get('/brands/{brand}', [BrandController::class, 'show']);
                Route::get('/products', [ProductController::class, 'index']);
                Route::get('/products/by-public-id/{publicId}', [ProductController::class, 'showByPublicId']);
                Route::get('/products/{product}', [ProductController::class, 'show']);
                Route::get('/attributes', [ProductAttributeController::class, 'index']);
            });

            Route::middleware('permission:catalog.manage')->scopeBindings()->group(function (): void {
                Route::post('/categories', [CategoryController::class, 'store']);
                Route::put('/categories/{category}', [CategoryController::class, 'update']);
                Route::delete('/categories/{category}', [CategoryController::class, 'destroy']);
                Route::post('/brands', [BrandController::class, 'store']);
                Route::put('/brands/{brand}', [BrandController::class, 'update']);
                Route::delete('/brands/{brand}', [BrandController::class, 'destroy']);
                Route::post('/products', [ProductController::class, 'store']);
                Route::put('/products/{product}', [ProductController::class, 'update']);
                Route::delete('/products/{product}', [ProductController::class, 'destroy']);
                Route::post('/products/{product}/publish', [ProductPublicationController::class, 'publish']);
                Route::post('/products/{product}/unpublish', [ProductPublicationController::class, 'unpublish']);
                Route::post('/products/{product}/variants', [ProductVariantController::class, 'store']);
                Route::put('/products/{product}/variants/{variant}', [ProductVariantController::class, 'update']);
                Route::delete('/products/{product}/variants/{variant}', [ProductVariantController::class, 'destroy']);
                Route::post('/products/{product}/images', [ProductImageController::class, 'store']);
                Route::delete('/products/{product}/images/{image}', [ProductImageController::class, 'destroy']);
                Route::post('/attributes', [ProductAttributeController::class, 'store']);
                Route::put('/attributes/{attribute}', [ProductAttributeController::class, 'update']);
                Route::delete('/attributes/{attribute}', [ProductAttributeController::class, 'destroy']);
                Route::post('/attributes/{attribute}/values', [ProductAttributeValueController::class, 'store']);
                Route::put('/attributes/{attribute}/values/{value}', [ProductAttributeValueController::class, 'update']);
                Route::delete('/attributes/{attribute}/values/{value}', [ProductAttributeValueController::class, 'destroy']);
            });

            Route::get('/products/{product}/variants/{variant}/inventory-movements', [InventoryAdjustmentController::class, 'index'])
                ->middleware('permission:inventory.view')->scopeBindings();
            Route::post('/products/{product}/variants/{variant}/inventory-adjustments', [InventoryAdjustmentController::class, 'store'])
                ->middleware('permission:inventory.manage')->scopeBindings();
        });
    });
});
