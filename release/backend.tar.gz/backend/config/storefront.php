<?php

return [
    // Temporary production preview. Set STORE_ADMIN_ONLY=false to open the store.
    'admin_only' => env('STORE_ADMIN_ONLY', env('APP_ENV', 'production') === 'production'),
];
