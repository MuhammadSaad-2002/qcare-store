<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('orders', function (Blueprint $table) {
            $table->uuid('checkout_key')->nullable()->unique();
            $table->string('payment_method', 32)->nullable();
            $table->string('shipping_zone')->nullable();
        });
        Schema::table('order_addresses', function (Blueprint $table) {
            $table->decimal('latitude', 10, 7)->nullable();
            $table->decimal('longitude', 10, 7)->nullable();
        });
    }

    public function down(): void
    {
        Schema::table('orders', fn (Blueprint $table) => $table->dropColumn(['checkout_key', 'payment_method', 'shipping_zone']));
        Schema::table('order_addresses', fn (Blueprint $table) => $table->dropColumn(['latitude', 'longitude']));
    }
};
