<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Str;

return new class extends Migration
{
    private const TABLES = [
        'categories', 'brands', 'customers', 'product_variants',
        'product_images', 'product_attributes', 'product_attribute_values',
    ];

    public function up(): void
    {
        foreach (self::TABLES as $tableName) {
            Schema::table($tableName, fn (Blueprint $table) => $table->uuid('public_id')->nullable()->unique());
            DB::table($tableName)->select('id')->orderBy('id')->chunkById(100, function ($rows) use ($tableName): void {
                foreach ($rows as $row) {
                    DB::table($tableName)->where('id', $row->id)->update(['public_id' => (string) Str::uuid()]);
                }
            });
            Schema::table($tableName, fn (Blueprint $table) => $table->uuid('public_id')->nullable(false)->change());
        }
    }

    public function down(): void
    {
        foreach (array_reverse(self::TABLES) as $tableName) {
            Schema::table($tableName, fn (Blueprint $table) => $table->dropColumn('public_id'));
        }
    }
};
