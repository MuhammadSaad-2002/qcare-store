<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Str;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('products', function (Blueprint $table): void {
            $table->json('disease_tags')->nullable();
        });
        DB::transaction(function (): void {
            $categories = DB::table('categories')->whereIn('slug', ['fever-pain', 'heart-circulation', 'blood-pressure', 'diabetes'])->get();
            foreach ($categories as $category) {
                $ids = DB::table('category_product')->where('category_id', $category->id)->pluck('product_id');
                foreach ($ids as $id) {
                    $tags = json_decode(DB::table('products')->where('id', $id)->value('disease_tags') ?? '[]', true);
                    $tags[] = $category->name;
                    DB::table('products')->where('id', $id)->update(['disease_tags' => json_encode(array_values(array_unique($tags)))]);
                }
                DB::table('category_product')->where('category_id', $category->id)->delete();
                DB::table('categories')->where('id', $category->id)->delete();
            }
        });
    }

    public function down(): void
    {
        foreach (DB::table('products')->whereNotNull('disease_tags')->get() as $product) {
            foreach (json_decode($product->disease_tags, true) as $name) {
                $slug = $name === 'Diabetes (Sugar)' ? 'diabetes' : Str::slug($name);
                $category = DB::table('categories')->where('slug', $slug)->first();
                $id = $category?->id ?? DB::table('categories')->insertGetId(['public_id' => (string) Str::uuid(), 'name' => $name, 'slug' => $slug, 'is_active' => true, 'sort_order' => 30, 'created_at' => now(), 'updated_at' => now()]);
                DB::table('category_product')->insertOrIgnore(['category_id' => $id, 'product_id' => $product->id]);
            }
        }
        Schema::table('products', function (Blueprint $table): void {
            $table->dropColumn('disease_tags');
        });
    }
};
