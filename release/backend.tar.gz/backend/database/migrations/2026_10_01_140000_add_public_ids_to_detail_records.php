<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Str;

return new class extends Migration
{
    public function up(): void
    {
        foreach (['orders', 'products'] as $tableName) {
            Schema::table($tableName, function (Blueprint $table) {
                $table->uuid('public_id')->nullable()->unique();
            });

            DB::table($tableName)->select('id')->orderBy('id')->chunkById(100, function ($rows) use ($tableName): void {
                foreach ($rows as $row) {
                    DB::table($tableName)->where('id', $row->id)->update(['public_id' => (string) Str::uuid()]);
                }
            });

            Schema::table($tableName, function (Blueprint $table) {
                $table->uuid('public_id')->nullable(false)->change();
            });
        }
    }

    public function down(): void
    {
        foreach (['orders', 'products'] as $tableName) {
            Schema::table($tableName, fn (Blueprint $table) => $table->dropColumn('public_id'));
        }
    }
};
