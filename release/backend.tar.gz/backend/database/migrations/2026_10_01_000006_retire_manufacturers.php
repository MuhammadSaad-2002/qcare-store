<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (DB::table('manufacturers')->exists() || DB::table('products')->whereNotNull('manufacturer_id')->exists()) {
            throw new RuntimeException('Manufacturer data exists. Review and migrate it before retiring manufacturers.');
        }

        Schema::table('products', function (Blueprint $table): void {
            $table->dropForeign(['manufacturer_id']);
            $table->dropIndex(['manufacturer_id', 'status']);
            $table->dropColumn('manufacturer_id');
        });
        Schema::drop('manufacturers');
    }

    public function down(): void
    {
        Schema::create('manufacturers', function (Blueprint $table): void {
            $table->id();
            $table->string('name');
            $table->string('slug')->unique();
            $table->char('country_code', 2)->nullable();
            $table->text('description')->nullable();
            $table->timestamps();
        });
        Schema::table('products', function (Blueprint $table): void {
            $table->foreignId('manufacturer_id')->nullable()->constrained()->nullOnDelete();
            $table->index(['manufacturer_id', 'status']);
        });
    }
};
