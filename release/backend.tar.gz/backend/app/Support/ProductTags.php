<?php

namespace App\Support;

use Illuminate\Support\Str;

class ProductTags
{
    public const FIELDS = ['disease' => 'disease_tags', 'use' => 'use_tags', 'type' => 'product_type_tags'];

    /** @return array<string, array<int, string>> */
    public static function rules(): array
    {
        $rules = [];
        foreach (self::FIELDS as $field) {
            $rules[$field] = ['sometimes', 'array', 'max:20'];
            $rules[$field.'.*'] = ['required', 'string', 'max:80', 'distinct:ignore_case', 'not_regex:/[|,]/'];
        }

        return $rules;
    }

    /** @param array<int, string> $existing
     * @param  array<int, string>  $additional
     * @return array<int, string>
     */
    public static function merge(array $existing, array $additional): array
    {
        return collect([...$existing, ...$additional])->map(fn (string $tag): string => Str::squish($tag))
            ->unique(fn (string $tag): string => Str::lower($tag))->values()->all();
    }
}
