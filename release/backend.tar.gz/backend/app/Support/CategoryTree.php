<?php

namespace App\Support;

use App\Models\Category;
use Illuminate\Database\Eloquent\Collection;

class CategoryTree
{
    /** @return Collection<int, Category> */
    public static function active(): Collection
    {
        $categories = Category::where('is_active', true)->orderBy('sort_order')->orderBy('name')->get();
        $byId = $categories->keyBy('id');

        return $categories->filter(function (Category $category) use ($byId): bool {
            $seen = [];
            while ($category) {
                if (isset($seen[$category->id])) {
                    return false;
                }
                $seen[$category->id] = true;
                if ($category->parent_id === null) {
                    return true;
                }
                $category = $byId->get($category->parent_id);
            }

            return false;
        })->values();
    }

    /**
     * @param  Collection<int, Category>  $categories
     * @return array<int, int>
     */
    public static function descendants(Collection $categories, int $id): array
    {
        $children = $categories->groupBy('parent_id');
        $ids = [];
        $queue = [$id];
        while ($queue !== []) {
            $current = array_pop($queue);
            if (isset($ids[$current])) {
                continue;
            }
            $ids[$current] = $current;
            foreach ($children->get($current, []) as $child) {
                $queue[] = $child->id;
            }
        }

        return array_values($ids);
    }
}
