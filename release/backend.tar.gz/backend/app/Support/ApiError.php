<?php

namespace App\Support;

use Illuminate\Auth\Access\AuthorizationException;
use Illuminate\Auth\AuthenticationException;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Http\Exceptions\ThrottleRequestsException;
use Illuminate\Http\JsonResponse;
use Illuminate\Validation\ValidationException;
use Symfony\Component\HttpKernel\Exception\HttpExceptionInterface;
use Throwable;

class ApiError
{
    public static function fromException(Throwable $exception): JsonResponse
    {
        $details = null;
        $headers = [];

        if ($exception instanceof ApiException) {
            [$status, $code, $message] = [$exception->status, $exception->errorCode, $exception->getMessage()];
        } elseif ($exception instanceof ValidationException) {
            [$status, $code, $message] = [422, 'validation_failed', 'The submitted data is invalid.'];
            $details = $exception->errors();
        } elseif ($exception instanceof AuthenticationException) {
            [$status, $code, $message] = [401, 'unauthenticated', 'Authentication is required.'];
        } elseif ($exception instanceof AuthorizationException) {
            [$status, $code, $message] = [403, 'forbidden', 'You do not have access to this resource.'];
        } elseif ($exception instanceof ModelNotFoundException) {
            [$status, $code, $message] = [404, 'not_found', 'The requested resource was not found.'];
        } elseif ($exception instanceof ThrottleRequestsException) {
            [$status, $code, $message] = [429, 'rate_limited', 'Too many requests. Please try again later.'];
            $headers = $exception->getHeaders();
        } elseif ($exception instanceof HttpExceptionInterface) {
            $status = $exception->getStatusCode();
            $code = match ($status) {
                403 => 'forbidden',
                404 => 'not_found',
                405 => 'method_not_allowed',
                419 => 'csrf_token_mismatch',
                default => 'http_error',
            };
            $message = match ($status) {
                403 => 'You do not have access to this resource.',
                404 => 'The requested resource was not found.',
                405 => 'This method is not allowed for the requested resource.',
                419 => 'Your session has expired. Please try again.',
                default => 'The request could not be completed.',
            };
            $headers = $exception->getHeaders();
        } else {
            [$status, $code, $message] = [500, 'server_error', 'An unexpected error occurred.'];
        }

        $error = ['code' => $code, 'message' => $message];
        if ($details !== null) {
            $error['details'] = $details;
        }

        return response()->json(['error' => $error], $status, $headers);
    }
}
