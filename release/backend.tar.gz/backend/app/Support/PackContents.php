<?php

namespace App\Support;

class PackContents
{
    public static function fromPosName(string $name, int $pieces): string
    {
        $unit = match (true) {
            (bool) preg_match('/\bCAP(?:S|SULES?)?\b/i', $name) => 'capsules',
            (bool) preg_match('/\bTABS?\b/i', $name) => 'tablets',
            (bool) preg_match('/\bSTRIPS?\b/i', $name) => 'strips',
            (bool) preg_match('/\bSWABS?\b/i', $name) => 'swabs',
            (bool) preg_match('/\bGLOVES?\b/i', $name) => 'gloves',
            default => 'pcs',
        };

        return "{$pieces} {$unit}";
    }
}
