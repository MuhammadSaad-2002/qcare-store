<?php

namespace App\Models\Concerns;

use Illuminate\Support\Str;

trait HasPublicId
{
    public function resolveRouteBinding($value, $field = null)
    {
        if ($field === null && Str::isUuid((string) $value)) {
            return $this->newQuery()->where('public_id', $value)->first();
        }

        return parent::resolveRouteBinding($value, $field);
    }

    public function resolveChildRouteBinding($childType, $value, $field)
    {
        return parent::resolveChildRouteBinding(
            $childType,
            $value,
            $field === null && Str::isUuid((string) $value) ? 'public_id' : $field
        );
    }

    protected static function bootHasPublicId(): void
    {
        static::creating(function ($model): void {
            if (! $model->public_id) {
                $model->public_id = (string) Str::uuid();
            }
        });
    }
}
