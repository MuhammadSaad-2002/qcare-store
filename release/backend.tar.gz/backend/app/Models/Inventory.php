<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Inventory extends Model
{
    protected $table = 'inventories';

    protected $fillable = [
        'product_variant_id', 'quantity_on_hand', 'low_stock_threshold',
        'tracks_stock', 'allows_backorder',
    ];

    protected function casts(): array
    {
        return ['tracks_stock' => 'boolean', 'allows_backorder' => 'boolean'];
    }

    public function variant(): BelongsTo
    {
        return $this->belongsTo(ProductVariant::class, 'product_variant_id');
    }
}
