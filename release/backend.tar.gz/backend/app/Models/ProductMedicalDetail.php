<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class ProductMedicalDetail extends Model
{
    protected $fillable = [
        'generic_name', 'active_ingredients', 'dosage_form',
        'requires_prescription', 'is_otc', 'information',
    ];

    protected function casts(): array
    {
        return [
            'requires_prescription' => 'boolean',
            'is_otc' => 'boolean',
            'information' => 'array',
        ];
    }

    public function product(): BelongsTo
    {
        return $this->belongsTo(Product::class);
    }
}
