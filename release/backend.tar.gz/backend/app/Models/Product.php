<?php

namespace App\Models;

use App\Models\Concerns\HasPublicId;
use App\Support\CategoryTree;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasManyThrough;
use Illuminate\Database\Eloquent\Relations\HasOne;
use Illuminate\Database\Eloquent\SoftDeletes;

class Product extends Model
{
    use HasPublicId;
    use SoftDeletes;

    protected $fillable = [
        'brand_id', 'name', 'slug', 'kind', 'status',
        'disease_tags', 'use_tags', 'product_type_tags', 'visibility', 'summary', 'description', 'is_featured',
    ];

    protected function casts(): array
    {
        return ['is_featured' => 'boolean', 'disease_tags' => 'array', 'use_tags' => 'array', 'product_type_tags' => 'array'];
    }

    public function scopeForStorefront(Builder $query, ?array $categoryIds = null): Builder
    {
        $categoryIds ??= CategoryTree::active()->modelKeys();

        return $query->where('status', 'published')->where('visibility', 'public')
            ->whereHas('categories', fn ($category) => $category->whereIn('categories.id', $categoryIds))
            ->whereHas('images', fn ($image) => $image->where('is_primary', true))
            ->whereHas('variants', fn ($variant) => $variant->where('status', 'active')->whereHas('inventory'));
    }

    public function brand(): BelongsTo
    {
        return $this->belongsTo(Brand::class);
    }

    public function categories(): BelongsToMany
    {
        return $this->belongsToMany(Category::class);
    }

    public function medicalDetails(): HasOne
    {
        return $this->hasOne(ProductMedicalDetail::class);
    }

    public function variants(): HasMany
    {
        return $this->hasMany(ProductVariant::class);
    }

    public function inventories(): HasManyThrough
    {
        return $this->hasManyThrough(Inventory::class, ProductVariant::class);
    }

    public function images(): HasMany
    {
        return $this->hasMany(ProductImage::class);
    }
}
