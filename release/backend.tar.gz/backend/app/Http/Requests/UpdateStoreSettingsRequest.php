<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class UpdateStoreSettingsRequest extends FormRequest
{
    public function authorize(): bool
    {
        return $this->user()?->can('settings.manage') ?? false;
    }

    public function rules(): array
    {
        return [
            'version' => ['required', 'string', 'size:64'],
            'values' => ['required', 'array:siteName,email,phone,whatsapp,address,hours'],
            'values.siteName' => ['required', 'string', 'max:120'],
            'values.email' => ['present', 'nullable', 'email:rfc', 'max:254'],
            'values.phone' => ['present', 'nullable', 'string', 'max:30', 'regex:/^\+?[0-9][0-9 ()-]{5,28}[0-9]$/'],
            'values.whatsapp' => ['present', 'nullable', 'string', 'regex:/^\+[1-9][0-9]{6,14}$/'],
            'values.address' => ['present', 'nullable', 'string', 'max:1000'],
            'values.hours' => ['present', 'nullable', 'string', 'max:500'],
        ];
    }

    public function attributes(): array
    {
        return [
            'values.siteName' => 'business name',
            'values.email' => 'support email',
            'values.phone' => 'phone number',
            'values.whatsapp' => 'WhatsApp number',
            'values.address' => 'business address',
            'values.hours' => 'opening hours',
        ];
    }

    public function messages(): array
    {
        return [
            'values.phone.regex' => 'Enter a phone number using digits, spaces, parentheses or hyphens.',
            'values.whatsapp.regex' => 'Use an international number starting with + and the country code, followed by digits only.',
        ];
    }
}
