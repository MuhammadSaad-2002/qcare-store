<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class UpdateOrderRequest extends FormRequest
{
    public function authorize(): bool
    {
        return $this->user()?->can('orders.manage') ?? false;
    }

    public function rules(): array
    {
        return [
            'version' => ['required', 'integer', 'min:1'],
            'status' => ['required', Rule::in(['pending', 'confirmed', 'processing', 'prescription_review', 'ready', 'shipped', 'out_for_delivery', 'delivered', 'cancelled', 'refunded'])],
            'payment_status' => ['sometimes', Rule::in(['pending', 'paid', 'failed', 'refunded'])],
            'note' => ['required', 'string', 'min:5', 'max:1000'],
            'items' => ['sometimes', 'array', 'min:1', 'max:100'],
            'items.*' => ['required', 'array:id,variant_public_id,quantity,unit_price'],
            'items.*.id' => ['required_without:items.*.variant_public_id', 'integer', 'min:1'],
            'items.*.variant_public_id' => ['required_without:items.*.id', 'uuid'],
            'items.*.quantity' => ['required', 'integer', 'min:1', 'max:10000'],
            'items.*.unit_price' => ['required', 'numeric', 'min:0', 'max:9999999999.99', 'decimal:0,2'],
            'discount_total' => ['sometimes', 'numeric', 'min:0', 'max:9999999999.99', 'decimal:0,2'],
            'tax_total' => ['sometimes', 'numeric', 'min:0', 'max:9999999999.99', 'decimal:0,2'],
            'shipping_total' => ['sometimes', 'numeric', 'min:0', 'max:9999999999.99', 'decimal:0,2'],
            'shipping' => ['sometimes', 'array:recipient_name,phone,line_1,line_2,area,city,region,postal_code,country_code,delivery_notes'],
            'shipping.recipient_name' => ['required_with:shipping', 'string', 'max:255'],
            'shipping.phone' => ['nullable', 'string', 'max:32'],
            'shipping.line_1' => ['required_with:shipping', 'string', 'max:255'],
            'shipping.line_2' => ['nullable', 'string', 'max:255'],
            'shipping.area' => ['nullable', 'string', 'max:255'],
            'shipping.city' => ['required_with:shipping', 'string', 'max:255'],
            'shipping.region' => ['nullable', 'string', 'max:255'],
            'shipping.postal_code' => ['nullable', 'string', 'max:32'],
            'shipping.country_code' => ['required_with:shipping', 'string', 'alpha:ascii', 'size:2'],
            'shipping.delivery_notes' => ['nullable', 'string', 'max:2000'],
            'billing' => ['sometimes', 'array:recipient_name,phone,line_1,line_2,area,city,region,postal_code,country_code,delivery_notes'],
            'billing.recipient_name' => ['required_with:billing', 'string', 'max:255'],
            'billing.phone' => ['nullable', 'string', 'max:32'],
            'billing.line_1' => ['required_with:billing', 'string', 'max:255'],
            'billing.line_2' => ['nullable', 'string', 'max:255'],
            'billing.area' => ['nullable', 'string', 'max:255'],
            'billing.city' => ['required_with:billing', 'string', 'max:255'],
            'billing.region' => ['nullable', 'string', 'max:255'],
            'billing.postal_code' => ['nullable', 'string', 'max:32'],
            'billing.country_code' => ['required_with:billing', 'string', 'alpha:ascii', 'size:2'],
            'billing.delivery_notes' => ['nullable', 'string', 'max:2000'],
        ];
    }
}
