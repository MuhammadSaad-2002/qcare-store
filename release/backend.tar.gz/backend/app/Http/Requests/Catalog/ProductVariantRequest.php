<?php

namespace App\Http\Requests\Catalog;

use App\Models\ProductAttributeValue;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;
use Illuminate\Validation\Validator;

class ProductVariantRequest extends FormRequest
{
    public function authorize(): bool
    {
        return $this->user()?->can('catalog.manage') ?? false;
    }

    public function rules(): array
    {
        $creating = $this->isMethod('post');

        return [
            'sku' => ['required', 'string', 'max:100', Rule::unique('product_variants', 'sku')->ignore($this->route('variant')?->id)],
            'barcode' => ['nullable', 'string', 'max:100', Rule::unique('product_variants', 'barcode')->ignore($this->route('variant')?->id)],
            'regular_price' => ['required', 'numeric', 'decimal:0,2', 'min:0', 'max:9999999999.99'],
            'sale_price' => ['nullable', 'numeric', 'decimal:0,2', 'min:0', 'max:9999999999.99', 'lte:regular_price'],
            'cost_price' => ['nullable', 'numeric', 'decimal:0,2', 'min:0', 'max:9999999999.99'],
            'currency_code' => ['required', 'string', 'size:3', 'uppercase'],
            'status' => ['required', Rule::in(['active', 'inactive'])],
            'sale_starts_at' => ['nullable', 'date'],
            'sale_ends_at' => ['nullable', 'date', 'after:sale_starts_at'],
            'value_ids' => ['present', 'array'],
            'value_ids.*' => ['integer', 'distinct', Rule::exists('product_attribute_values', 'id')],
            'inventory' => [$creating ? 'required' : 'prohibited', 'array'],
            'inventory.quantity_on_hand' => [$creating ? 'required' : 'prohibited', 'integer', 'min:0', 'max:4294967295'],
            'inventory.low_stock_threshold' => [$creating ? 'required' : 'prohibited', 'integer', 'min:0', 'max:4294967295'],
            'inventory.tracks_stock' => [$creating ? 'required' : 'prohibited', 'boolean'],
            'inventory.allows_backorder' => [$creating ? 'required' : 'prohibited', 'boolean'],
        ];
    }

    public function after(): array
    {
        return [function (Validator $validator): void {
            $ids = $this->input('value_ids', []);
            if (! is_array($ids) || collect($ids)->contains(fn ($id) => ! is_numeric($id))) {
                return;
            }
            $count = ProductAttributeValue::query()->whereIn('id', $ids)->distinct()->count('product_attribute_id');
            if ($count !== count($ids)) {
                $validator->errors()->add('value_ids', 'Select at most one value from each attribute.');
            }
        }];
    }
}
