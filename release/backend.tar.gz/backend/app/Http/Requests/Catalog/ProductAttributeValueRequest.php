<?php

namespace App\Http\Requests\Catalog;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class ProductAttributeValueRequest extends FormRequest
{
    public function authorize(): bool
    {
        return $this->user()?->can('catalog.manage') ?? false;
    }

    public function rules(): array
    {
        return [
            'value' => ['required', 'string', 'max:255', Rule::unique('product_attribute_values')->where('product_attribute_id', $this->route('attribute')?->id)->ignore($this->route('value')?->id)],
            'sort_order' => ['required', 'integer', 'min:0'],
        ];
    }
}
