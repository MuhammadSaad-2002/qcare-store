<?php

namespace App\Http\Requests\Catalog;

use App\Models\Product;
use App\Support\ProductTags;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Support\Str;
use Illuminate\Validation\Rule;
use Illuminate\Validation\Validator;

class ProductRequest extends FormRequest
{
    protected function prepareForValidation(): void
    {
        $submitted = array_filter(ProductTags::FIELDS, fn (string $field): bool => is_array($this->input($field)));
        if ($submitted === []) {
            return;
        }
        $existing = Product::get(array_values($submitted));
        $normalized = [];
        foreach ($submitted as $field) {
            $labels = $existing->pluck($field)->filter()->flatten()->mapWithKeys(fn (string $tag): array => [Str::lower($tag) => $tag]);
            $normalized[$field] = array_map(function (mixed $tag) use ($labels): mixed {
                if (! is_string($tag)) {
                    return $tag;
                }
                $tag = Str::squish($tag);

                return $labels[Str::lower($tag)] ?? $tag;
            }, $this->input($field));
        }
        $this->merge($normalized);
    }

    public function authorize(): bool
    {
        return $this->user()?->can('catalog.manage') ?? false;
    }

    public function rules(): array
    {
        $creating = $this->isMethod('post');

        return [
            'name' => ['required', 'string', 'max:255'],
            'slug' => ['required', 'alpha_dash:ascii', 'max:255', Rule::unique('products')->ignore($this->route('product')?->id)],
            'kind' => ['required', Rule::in(['general', 'medicine'])],
            'visibility' => ['required', Rule::in(['public', 'hidden'])],
            'summary' => ['nullable', 'string', 'max:2000'],
            'description' => ['nullable', 'string'],
            'is_featured' => ['required', 'boolean'],
            'brand_id' => ['nullable', 'integer', Rule::exists('brands', 'id')],
            'manufacturer_id' => ['prohibited'],
            'category_ids' => ['present', 'array'],
            'category_ids.*' => ['integer', 'distinct', Rule::exists('categories', 'id')],
            ...ProductTags::rules(),
            'medical' => ['nullable', 'array'],
            'medical.generic_name' => ['nullable', 'string', 'max:255'],
            'medical.active_ingredients' => ['nullable', 'string'],
            'medical.dosage_form' => ['nullable', 'string', 'max:255'],
            'medical.requires_prescription' => ['nullable', 'boolean'],
            'medical.is_otc' => ['nullable', 'boolean'],
            'medical.information' => ['nullable', 'array:storage,usage,directions,warnings,precautions,contraindications,side_effects,ingredients,additional'],
            'medical.information.*' => ['nullable', 'string', 'max:10000'],
            'variant' => [$creating ? 'required' : 'prohibited', 'array'],
            'variant.sku' => [$creating ? 'required' : 'prohibited', 'string', 'max:100', Rule::unique('product_variants', 'sku')],
            'variant.regular_price' => [$creating ? 'required' : 'prohibited', 'numeric', 'decimal:0,2', 'min:0', 'max:9999999999.99'],
            'variant.currency_code' => [$creating ? 'required' : 'prohibited', 'string', 'size:3', 'uppercase'],
            'variant.quantity_on_hand' => [$creating ? 'required' : 'prohibited', 'integer', 'min:0', 'max:4294967295'],
        ];
    }

    public function after(): array
    {
        return [function (Validator $validator): void {
            if ($this->input('kind') !== 'medicine' && $this->filled('medical')) {
                $validator->errors()->add('medical', 'Medical details are only valid for medicines.');
            }
            if ($this->boolean('medical.requires_prescription') && $this->boolean('medical.is_otc')) {
                $validator->errors()->add('medical.is_otc', 'A prescription medicine cannot be marked OTC.');
            }
        }];
    }
}
