<?php

namespace App\Http\Requests\Catalog;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Validator;

class ProductImageRequest extends FormRequest
{
    public function authorize(): bool
    {
        return $this->user()?->can('catalog.manage') ?? false;
    }

    public function rules(): array
    {
        return [
            'image' => ['required', 'image', 'mimes:jpg,jpeg,png,webp', 'max:4096'],
            'alt_text' => ['nullable', 'string', 'max:255'],
            'is_primary' => ['required', 'boolean'],
            'sort_order' => ['required', 'integer', 'min:0'],
            'product_variant_id' => ['nullable', 'integer', 'exists:product_variants,id'],
        ];
    }

    public function after(): array
    {
        return [function (Validator $validator): void {
            $variantId = $this->input('product_variant_id');
            if ($variantId === null || $validator->errors()->has('product_variant_id')) {
                return;
            }
            if (! $this->route('product')->variants()->whereKey($variantId)->exists()) {
                $validator->errors()->add('product_variant_id', 'The selected variant does not belong to this product.');
            }
        }];
    }
}
