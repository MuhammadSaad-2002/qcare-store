<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class UpdateDashboardGoalsRequest extends FormRequest
{
    public function authorize(): bool
    {
        return $this->user()?->can('settings.manage') ?? false;
    }

    public function rules(): array
    {
        return [
            'month' => ['required', 'string', Rule::in([now('Asia/Karachi')->format('Y-m')])],
            'version' => ['required', 'string', 'size:64'],
            'values' => ['required', 'array:revenue,customers,averageOrderValue'],
            'values.revenue' => ['present', 'nullable', 'numeric', 'decimal:0,2', 'min:0.01', 'max:9999999999.99'],
            'values.customers' => ['present', 'nullable', 'integer', 'min:1', 'max:10000000'],
            'values.averageOrderValue' => ['present', 'nullable', 'numeric', 'decimal:0,2', 'min:0.01', 'max:9999999999.99'],
        ];
    }

    public function attributes(): array
    {
        return ['values.revenue' => 'monthly revenue target', 'values.customers' => 'new customer target', 'values.averageOrderValue' => 'average order value target'];
    }

    public function messages(): array
    {
        return ['month.in' => 'The month has changed. Reload the dashboard to set goals for the current month.'];
    }
}
