<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Http\Resources\Api\V1\CustomerOrderResource;
use App\Models\Order;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\AnonymousResourceCollection;

class CustomerOrderController extends Controller
{
    public function index(Request $request): AnonymousResourceCollection
    {
        $customerId = $request->user()->customer?->id ?? 0;

        return CustomerOrderResource::collection(
            Order::query()->where('customer_id', $customerId)
                ->withCount('items')->latest('placed_at')->paginate(10)
        );
    }

    public function show(Request $request, string $number): CustomerOrderResource
    {
        $customerId = $request->user()->customer?->id ?? 0;
        $order = Order::query()->where('customer_id', $customerId)
            ->where('order_number', $number)->with(['items', 'addresses'])->firstOrFail();

        return new CustomerOrderResource($order);
    }
}
