<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Models\Order;
use App\Models\ProductVariant;
use App\Models\Setting;
use App\Models\User;
use App\Support\ApiException;
use App\Support\CategoryTree;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

class CheckoutController extends Controller
{
    public function zones(): JsonResponse
    {
        return response()->json(['data' => array_values(array_filter(Setting::where('key', 'shipping.zones')->first()?->value ?? [], fn ($zone) => $zone['active']))]);
    }

    public function store(Request $request): JsonResponse
    {
        $data = $request->validate([
            'checkout_key' => ['required', 'uuid'],
            'payment_method' => ['required', 'in:cod'],
            'zone_id' => ['required', 'uuid'],
            'expected_total' => ['required', 'numeric', 'min:0'],
            'items' => ['required', 'array', 'min:1', 'max:100'],
            'items.*.sku' => ['required', 'string', 'max:100', 'distinct'],
            'items.*.quantity' => ['required', 'integer', 'between:1,99'],
            'address' => ['required', 'array:recipient_name,phone,line_1,line_2,area,city,region,postal_code,country_code,delivery_notes'],
            'address.recipient_name' => ['required', 'string', 'max:255'],
            'address.phone' => ['required', 'string', 'regex:/^\+?[0-9 ()-]{7,25}$/'],
            'address.line_1' => ['required', 'string', 'max:255'],
            'address.line_2' => ['nullable', 'string', 'max:255'],
            'address.area' => ['nullable', 'string', 'max:255'],
            'address.city' => ['required', 'string', 'max:100'],
            'address.region' => ['nullable', 'string', 'max:100'],
            'address.postal_code' => ['nullable', 'string', 'max:32'],
            'address.country_code' => ['required', 'in:PK'],
            'address.delivery_notes' => ['nullable', 'string', 'max:1000'],
        ]);
        $order = DB::transaction(function () use ($data, $request): Order {
            $user = User::whereKey($request->user()->id)->lockForUpdate()->firstOrFail();
            abort_unless($user->is_active, 403);
            $existing = Order::where('checkout_key', $data['checkout_key'])->first();
            if ($existing) {
                abort_unless($existing->customer?->user_id === $user->id, 409);

                return $existing;
            }
            $zones = Setting::where('key', 'shipping.zones')->lockForUpdate()->first()?->value ?? [];
            $zone = collect($zones)->first(fn ($zone) => $zone['id'] === $data['zone_id'] && $zone['active'] && in_array(mb_strtolower(trim($data['address']['city'])), array_map(fn ($city) => mb_strtolower(trim($city)), $zone['cities']), true));
            if (! $zone) {
                throw new ApiException('shipping_unavailable', 'Choose an available delivery city and shipping zone.', 422);
            }
            $lines = [];
            $subtotal = 0;
            $prescription = false;
            $categoryIds = CategoryTree::active()->modelKeys();
            foreach (collect($data['items'])->sortBy('sku') as $line) {
                $variant = ProductVariant::where('sku', $line['sku'])->where('status', 'active')
                    ->whereHas('product', fn ($q) => $q->forStorefront($categoryIds))
                    ->with('product.medicalDetails')->lockForUpdate()->first();
                $inventory = $variant?->inventory()->lockForUpdate()->first();
                if (! $variant || ! $inventory || $variant->currency_code !== 'PKR' || ($inventory->tracks_stock && ! $inventory->allows_backorder && $inventory->quantity_on_hand < $line['quantity'])) {
                    throw new ApiException('cart_unavailable', 'An item is unavailable or has insufficient stock. Please review your cart.', 422);
                }
                $sale = $variant->sale_price !== null && ($variant->sale_starts_at === null || $variant->sale_starts_at->isPast()) && ($variant->sale_ends_at === null || $variant->sale_ends_at->isFuture());
                $price = (int) round((float) ($sale ? $variant->sale_price : $variant->regular_price) * 100);
                $subtotal += $price * $line['quantity'];
                $lines[] = [$variant, $inventory, $line['quantity'], $price];
                $prescription = $prescription || (bool) $variant->product->medicalDetails?->requires_prescription;
            }
            $shipping = (int) round((float) $zone['rate'] * 100);
            if ($subtotal + $shipping !== (int) round($data['expected_total'] * 100)) {
                throw new ApiException('price_changed', 'Prices or delivery charges have changed. Refresh checkout to review the updated total.', 409);
            }
            $customer = $user->customer()->firstOrCreate([]);
            $order = Order::create(['checkout_key' => $data['checkout_key'], 'order_number' => 'QC-'.Str::upper(Str::random(16)), 'customer_id' => $customer->id, 'customer_name' => $data['address']['recipient_name'], 'customer_email' => $user->email, 'customer_phone' => $data['address']['phone'], 'status' => $prescription ? 'prescription_review' : 'pending', 'payment_status' => 'pending', 'payment_method' => 'cod', 'shipping_zone' => $zone['name'], 'currency_code' => 'PKR', 'subtotal' => $subtotal / 100, 'shipping_total' => $shipping / 100, 'grand_total' => ($subtotal + $shipping) / 100, 'placed_at' => now()]);
            foreach ($lines as [$variant, $inventory, $quantity, $price]) {
                $order->items()->create(['product_id' => $variant->product_id, 'product_variant_id' => $variant->id, 'product_name' => $variant->product->name, 'variant_sku' => $variant->sku, 'quantity' => $quantity, 'unit_price' => $price / 100, 'line_total' => ($price * $quantity) / 100]);
                if ($inventory->tracks_stock) {
                    $before = $inventory->quantity_on_hand;
                    $after = max(0, $before - $quantity);
                    $inventory->update(['quantity_on_hand' => $after]);
                    $variant->movements()->create(['user_id' => $user->id, 'delta' => $after - $before, 'quantity_before' => $before, 'quantity_after' => $after, 'reason' => 'Checkout '.$order->order_number]);
                }
            }
            foreach (['billing', 'shipping'] as $type) {
                $order->addresses()->create([...$data['address'], 'type' => $type]);
            }
            $order->statusHistory()->create(['to_status' => $order->status, 'actor_user_id' => $user->id, 'note' => 'Cash on delivery checkout. Prescription items require pharmacist approval before fulfilment.', 'created_at' => now()]);

            return $order;
        }, 3);

        return response()->json(['data' => ['number' => $order->order_number, 'total' => $order->grand_total, 'status' => $order->status]], 201);
    }
}
