<?php

namespace App\Http\Controllers\Api\V1\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\Catalog\ProductImageRequest;
use App\Models\Product;
use App\Models\ProductImage;
use App\Services\Catalog\PublicationGuard;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;

class ProductImageController extends Controller
{
    public function store(ProductImageRequest $request, Product $product): JsonResponse
    {
        $data = $request->validated();
        $path = $request->file('image')->store('products/'.$product->id, 'public');

        try {
            $image = DB::transaction(function () use ($product, $data, $path): ProductImage {
                if ($data['is_primary']) {
                    $product->images()->update(['is_primary' => false]);
                }

                return $product->images()->create([
                    'path' => $path,
                    'alt_text' => $data['alt_text'] ?? null,
                    'is_primary' => $data['is_primary'],
                    'sort_order' => $data['sort_order'],
                    'product_variant_id' => $data['product_variant_id'] ?? null,
                ]);
            });
        } catch (\Throwable $exception) {
            Storage::disk('public')->delete($path);
            throw $exception;
        }

        return response()->json(['data' => $image], 201);
    }

    public function destroy(Product $product, ProductImage $image, PublicationGuard $guard): JsonResponse
    {
        DB::transaction(function () use ($product, $image, $guard): void {
            $image->delete();
            if ($product->status === 'published') {
                $guard->assertCanPublish($product);
            }
        });
        Storage::disk('public')->delete($image->path);

        return response()->json(['data' => ['deleted' => true]]);
    }
}
