<?php

namespace App\Http\Controllers\Api\V1\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\Catalog\ProductAttributeValueRequest;
use App\Models\ProductAttribute;
use App\Models\ProductAttributeValue;
use App\Support\ApiException;
use Illuminate\Http\JsonResponse;

class ProductAttributeValueController extends Controller
{
    public function store(ProductAttributeValueRequest $request, ProductAttribute $attribute): JsonResponse
    {
        return response()->json(['data' => $attribute->values()->create($request->validated())], 201);
    }

    public function update(ProductAttributeValueRequest $request, ProductAttribute $attribute, ProductAttributeValue $value): JsonResponse
    {
        $value->update($request->validated());

        return response()->json(['data' => $value->fresh()]);
    }

    public function destroy(ProductAttribute $attribute, ProductAttributeValue $value): JsonResponse
    {
        if ($value->variants()->exists()) {
            throw new ApiException('attribute_value_in_use', 'Remove variant selections before deleting this value.', 409);
        }
        $value->delete();

        return response()->json(['data' => ['deleted' => true]]);
    }
}
