<?php

namespace App\Http\Controllers\Api\V1\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\UpdateDashboardGoalsRequest;
use App\Services\AdminDashboardService;
use App\Services\DashboardGoalsService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class AdminDashboardController extends Controller
{
    public function show(Request $request, AdminDashboardService $dashboard): JsonResponse
    {
        $values = $request->validate(['period' => ['sometimes', 'string', 'in:today,7d,30d']]);

        return response()->json(['data' => $dashboard->get($request->user(), $values['period'] ?? 'today')]);
    }

    public function updateGoals(UpdateDashboardGoalsRequest $request, DashboardGoalsService $goals): JsonResponse
    {
        return response()->json(['data' => $goals->update($request->validated('month'), $request->validated('values'), $request->validated('version'), $request->user())]);
    }
}
