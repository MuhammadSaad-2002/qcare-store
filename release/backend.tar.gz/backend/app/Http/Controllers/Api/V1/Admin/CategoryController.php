<?php

namespace App\Http\Controllers\Api\V1\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\AdminDirectoryRequest;
use App\Http\Requests\Catalog\CategoryRequest;
use App\Models\Category;
use App\Support\ApiException;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\Storage;

class CategoryController extends Controller
{
    public function index(AdminDirectoryRequest $request): JsonResponse
    {
        $query = Category::query()->with('parent:id,name')->withCount('products');
        if ($request->filled('q')) {
            $search = '%'.$request->validated('q').'%';
            $query->where(fn (Builder $query) => $query->where('name', 'like', $search)->orWhere('slug', 'like', $search));
        }
        if ($request->filled('status')) {
            $query->where('is_active', $request->validated('status') === 'active');
        }
        $categories = $query->orderBy('sort_order')->orderBy('name')->orderBy('id')->paginate($request->integer('per_page', 20));

        return response()->json(['data' => $categories->items(), 'meta' => [
            'currentPage' => $categories->currentPage(), 'lastPage' => $categories->lastPage(), 'total' => $categories->total(),
        ]]);
    }

    public function store(CategoryRequest $request): JsonResponse
    {
        $data = $request->safe()->except('image');
        $path = $request->file('image')?->store('categories', 'public');
        try {
            $category = Category::create([...$data, 'image_path' => $path]);
        } catch (\Throwable $exception) {
            if ($path) {
                Storage::disk('public')->delete($path);
            }
            throw $exception;
        }

        return response()->json(['data' => $category], 201);
    }

    public function show(Category $category): JsonResponse
    {
        return response()->json(['data' => $category->load('parent:id,name')]);
    }

    public function update(CategoryRequest $request, Category $category): JsonResponse
    {
        $data = $request->safe()->except('image');
        $path = $request->file('image')?->store('categories', 'public');
        $oldPath = $category->image_path;
        try {
            $category->update([...$data, ...($path ? ['image_path' => $path] : [])]);
        } catch (\Throwable $exception) {
            if ($path) {
                Storage::disk('public')->delete($path);
            }
            throw $exception;
        }
        if ($path && $oldPath) {
            Storage::disk('public')->delete($oldPath);
        }

        return response()->json(['data' => $category->fresh()]);
    }

    public function destroy(Category $category): JsonResponse
    {
        if ($category->children()->exists() || $category->products()->exists()) {
            throw new ApiException('category_in_use', 'Remove child categories and product assignments before deleting this category.', 409);
        }
        $category->delete();
        if ($category->image_path) {
            Storage::disk('public')->delete($category->image_path);
        }

        return response()->json(['data' => ['deleted' => true]]);
    }
}
