<?php

namespace App\Http\Controllers\Api\V1\Admin;

use App\Http\Controllers\Controller;
use App\Models\Setting;
use App\Models\SettingChange;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class ShippingSettingsController extends Controller
{
    public function show(): JsonResponse
    {
        return response()->json(['data' => Setting::where('key', 'shipping.zones')->first()?->value ?? []]);
    }

    public function update(Request $request): JsonResponse
    {
        $data = $request->validate([
            'zones' => ['present', 'array', 'max:100'],
            'zones.*.id' => ['required', 'uuid', 'distinct'],
            'zones.*.name' => ['required', 'string', 'max:100'],
            'zones.*.cities' => ['required', 'array', 'min:1', 'max:1000'],
            'zones.*.cities.*' => ['required', 'string', 'max:100'],
            'zones.*.rate' => ['required', 'numeric', 'min:0', 'max:100000'],
            'zones.*.active' => ['required', 'boolean'],
        ]);
        foreach ($data['zones'] as &$zone) {
            $zone['cities'] = array_values(array_unique(array_map('trim', $zone['cities'])));
        }
        unset($zone);
        DB::transaction(function () use ($data, $request): void {
            $before = Setting::where('key', 'shipping.zones')->lockForUpdate()->first()?->value;
            Setting::updateOrCreate(['key' => 'shipping.zones'], ['group' => 'shipping', 'is_public' => false, 'value' => $data['zones']]);
            SettingChange::create(['user_id' => $request->user()->id, 'changes' => ['shipping.zones' => ['before' => $before, 'after' => $data['zones']]]]);
        });

        return $this->show();
    }
}
