<?php

namespace App\Http\Controllers\Api\V1\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\AdminCustomerRequest;
use App\Http\Requests\AdminDirectoryRequest;
use App\Http\Resources\CustomerResource;
use App\Models\Customer;
use App\Models\User;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;

class CustomerController extends Controller
{
    public function index(AdminDirectoryRequest $request): JsonResponse
    {
        $query = Customer::query()->with([
            'user:id,name,email,is_active',
            'addresses' => fn (HasMany $query) => $query->select('id', 'customer_id', 'country_code')->where('is_default', true)->orderBy('id')->limit(1),
        ]);
        if ($request->filled('q')) {
            $search = '%'.$request->validated('q').'%';
            $query->where(fn (Builder $query) => $query->where('phone', 'like', $search)
                ->orWhereHas('user', fn (Builder $query) => $query->where('name', 'like', $search)->orWhere('email', 'like', $search)));
        }
        if ($request->filled('status')) {
            $query->whereHas('user', fn (Builder $query) => $query->where('is_active', $request->validated('status') === 'active'));
        }
        $customers = $query->orderByDesc('created_at')->orderByDesc('id')->paginate($request->integer('per_page', 8));

        return response()->json(['data' => CustomerResource::collection($customers)->resolve(), 'meta' => [
            'currentPage' => $customers->currentPage(), 'lastPage' => $customers->lastPage(), 'total' => $customers->total(),
        ]]);
    }

    public function store(AdminCustomerRequest $request): JsonResponse
    {
        $data = $request->validated();
        $path = $request->file('avatar')?->store('customer-avatars');
        try {
            $customer = DB::transaction(function () use ($data, $path): Customer {
                $user = User::create([
                    'name' => $data['name'],
                    'email' => $data['email'],
                    'password' => Str::random(64),
                    'is_active' => false,
                ]);
                $user->assignRole('customer');

                return $user->customer()->create([
                    'phone' => $data['phone'] ?? null,
                    'country_code' => isset($data['country_code']) ? strtoupper($data['country_code']) : null,
                    'joined_at' => $data['joined_at'],
                    'avatar_path' => $path,
                ]);
            });
        } catch (\Throwable $exception) {
            if ($path) {
                Storage::delete($path);
            }
            throw $exception;
        }

        return response()->json(['data' => (new CustomerResource($customer->load('user', 'addresses')))->resolve()], 201);
    }

    public function avatar(Customer $customer): Response
    {
        abort_if(! $customer->avatar_path || ! Storage::exists($customer->avatar_path), 404);

        return response(Storage::get($customer->avatar_path))
            ->header('Content-Type', Storage::mimeType($customer->avatar_path) ?: 'application/octet-stream')
            ->header('Cache-Control', 'private, max-age=300')
            ->header('X-Content-Type-Options', 'nosniff');
    }
}
