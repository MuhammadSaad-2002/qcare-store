<?php

namespace App\Http\Controllers\Api\V1\Admin;

use App\Http\Controllers\Controller;
use App\Http\Resources\ProductResource;
use App\Models\Product;
use App\Services\Catalog\PublicationGuard;

class ProductPublicationController extends Controller
{
    public function publish(Product $product, PublicationGuard $guard): ProductResource
    {
        $guard->assertCanPublish($product);
        $product->update(['status' => 'published']);

        return new ProductResource($product->fresh()->load(['categories', 'medicalDetails', 'variants.inventory', 'images']));
    }

    public function unpublish(Product $product): ProductResource
    {
        $product->update(['status' => 'draft']);

        return new ProductResource($product->fresh());
    }
}
