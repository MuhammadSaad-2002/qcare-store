<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Services\PublicSettingsService;
use Illuminate\Http\JsonResponse;

class SiteSettingsController extends Controller
{
    public function __invoke(PublicSettingsService $settings): JsonResponse
    {
        return response()->json(['data' => $settings->get()]);
    }
}
