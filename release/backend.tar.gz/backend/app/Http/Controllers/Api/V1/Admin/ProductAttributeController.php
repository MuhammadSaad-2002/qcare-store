<?php

namespace App\Http\Controllers\Api\V1\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\Catalog\ProductAttributeRequest;
use App\Models\ProductAttribute;
use App\Support\ApiException;
use Illuminate\Http\JsonResponse;

class ProductAttributeController extends Controller
{
    public function index(): JsonResponse
    {
        return response()->json(['data' => ProductAttribute::query()->with(['values' => fn ($query) => $query->orderBy('sort_order')->orderBy('value')])->orderBy('sort_order')->orderBy('name')->get()]);
    }

    public function store(ProductAttributeRequest $request): JsonResponse
    {
        return response()->json(['data' => ProductAttribute::create($request->validated())], 201);
    }

    public function update(ProductAttributeRequest $request, ProductAttribute $attribute): JsonResponse
    {
        $attribute->update($request->validated());

        return response()->json(['data' => $attribute->fresh()->load('values')]);
    }

    public function destroy(ProductAttribute $attribute): JsonResponse
    {
        if ($attribute->values()->whereHas('variants')->exists()) {
            throw new ApiException('attribute_in_use', 'Remove variant selections before deleting this attribute.', 409);
        }
        $attribute->delete();

        return response()->json(['data' => ['deleted' => true]]);
    }
}
