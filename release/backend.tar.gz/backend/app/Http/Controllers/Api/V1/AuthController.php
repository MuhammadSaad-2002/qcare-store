<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Http\Requests\LoginRequest;
use App\Http\Requests\RegisterCustomerRequest;
use App\Http\Resources\UserResource;
use App\Services\AuthenticationService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class AuthController extends Controller
{
    public function __construct(private readonly AuthenticationService $authentication) {}

    public function register(RegisterCustomerRequest $request): JsonResponse
    {
        $user = $this->authentication->register($request->validated(), $request);

        return (new UserResource($user))->response()->setStatusCode(201);
    }

    public function login(LoginRequest $request): UserResource
    {
        return new UserResource($this->authentication->login($request->validated(), $request));
    }

    public function adminLogin(LoginRequest $request): UserResource
    {
        return new UserResource($this->authentication->login($request->validated(), $request, true));
    }

    public function me(Request $request): UserResource
    {
        return new UserResource($request->user());
    }

    public function logout(Request $request): JsonResponse
    {
        $this->authentication->logout($request);

        return response()->json(['data' => ['message' => 'Signed out.']]);
    }
}
