<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Http\Resources\PublicProductResource;
use App\Models\Product;
use App\Models\ProductVariant;
use App\Support\CategoryTree;
use App\Support\ProductTags;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;

class PublicProductController extends Controller
{
    public function index(Request $request): JsonResponse
    {
        foreach (['category', 'brand', ...array_keys(ProductTags::FIELDS)] as $key) {
            if (is_string($request->input($key))) {
                $request->merge([$key => array_values(array_filter(explode('|', $request->input($key))))]);
            }
        }
        $filters = $request->validate([
            'category' => ['nullable', 'array', 'max:50'],
            'category.*' => ['required', 'alpha_dash:ascii', 'max:255', Rule::exists('categories', 'slug')->where('is_active', true)],
            'brand' => ['nullable', 'array', 'max:50'],
            'brand.*' => ['required', 'alpha_dash:ascii', 'max:255', Rule::exists('brands', 'slug')->where('is_active', true)],
            'q' => ['nullable', 'string', 'max:100'],
            'letter' => ['nullable', 'string', 'regex:/^[A-Z]$/'],
            'disease' => ['nullable', 'array', 'max:50'],
            'disease.*' => ['required', 'string', 'max:80'],
            'use' => ['nullable', 'array', 'max:50'],
            'use.*' => ['required', 'string', 'max:80'],
            'type' => ['nullable', 'array', 'max:50'],
            'type.*' => ['required', 'string', 'max:80'],
            'page' => ['nullable', 'integer', 'min:1'],
            'per_page' => ['nullable', 'integer', 'between:1,48'],
            'on_sale' => ['nullable', 'boolean'],
            'sort' => ['nullable', Rule::in(['latest', 'oldest', 'name_asc', 'name_desc', 'price_asc', 'price_desc'])],
        ]);
        $products = $this->visibleProducts();
        $categoryIds = [];
        if (! empty($filters['category'])) {
            $categories = CategoryTree::active();
            foreach ($categories->whereIn('slug', $filters['category']) as $category) {
                $categoryIds = [...$categoryIds, ...CategoryTree::descendants($categories, $category->id)];
            }
        }
        foreach (ProductTags::FIELDS as $key => $field) {
            $products->when(! empty($filters[$key]), fn ($query) => $query->where(function ($tags) use ($filters, $key, $field): void {
                foreach ($filters[$key] as $tag) {
                    $tags->orWhereJsonContains($field, $tag);
                }
            }));
        }
        $products
            ->when(! empty($filters['category']), fn ($query) => $query->whereHas('categories', fn ($category) => $category->whereIn('categories.id', array_unique($categoryIds))))
            ->when(! empty($filters['brand']), fn ($query) => $query->whereHas('brand', fn ($brand) => $brand->whereIn('slug', $filters['brand'])->where('is_active', true)))
            ->when(isset($filters['q']), fn ($query) => $query->where('name', 'like', '%'.$filters['q'].'%'))
            ->when(isset($filters['letter']), fn ($query) => $query->where('name', 'like', $filters['letter'].'%'))
            ->when($filters['on_sale'] ?? false, fn ($query) => $query->whereHas('variants', fn ($variant) => $variant
                ->where('status', 'active')->whereHas('inventory')
                ->whereNotNull('sale_price')->whereColumn('sale_price', '<', 'regular_price')
                ->where(fn ($date) => $date->whereNull('sale_starts_at')->orWhere('sale_starts_at', '<=', now()))
                ->where(fn ($date) => $date->whereNull('sale_ends_at')->orWhere('sale_ends_at', '>=', now()))))
            ->with(['brand:id,name,slug,logo_path', 'categories:id,name,slug', 'images' => fn ($query) => $query->where('is_primary', true), 'variants' => fn ($query) => $query->where('status', 'active')->whereHas('inventory')->orderBy('id')->with(['inventory', 'values.attribute'])]);

        $sort = $filters['sort'] ?? 'latest';
        if (in_array($sort, ['price_asc', 'price_desc'], true)) {
            $now = now();
            $price = ProductVariant::query()
                ->selectRaw('CASE WHEN sale_price IS NOT NULL AND (sale_starts_at IS NULL OR sale_starts_at < ?) AND (sale_ends_at IS NULL OR sale_ends_at > ?) THEN sale_price ELSE regular_price END', [$now, $now])
                ->whereColumn('product_id', 'products.id')
                ->where('status', 'active')->whereHas('inventory')->orderBy('id')->limit(1);
            $products->orderBy($price, $sort === 'price_asc' ? 'asc' : 'desc')->orderBy('id');
        } elseif (in_array($sort, ['name_asc', 'name_desc'], true)) {
            $products->orderBy('name', $sort === 'name_asc' ? 'asc' : 'desc')->orderBy('id');
        } else {
            $products->orderBy('id', $sort === 'oldest' ? 'asc' : 'desc');
        }
        $products = $products->paginate($filters['per_page'] ?? 12);

        return response()->json(['data' => PublicProductResource::collection($products->items())->resolve(), 'meta' => [
            'currentPage' => $products->currentPage(), 'lastPage' => $products->lastPage(), 'total' => $products->total(),
        ]]);
    }

    public function diseases(): JsonResponse
    {
        $tags = $this->visibleProducts()->whereNotNull('disease_tags')->pluck('disease_tags')
            ->flatten()->unique()->sort()->values();

        return response()->json(['data' => $tags]);
    }

    public function tags(): JsonResponse
    {
        $products = $this->visibleProducts()->get(array_values(ProductTags::FIELDS));
        $groups = [];
        foreach (ProductTags::FIELDS as $key => $field) {
            $groups[$key] = $products->pluck($field)->filter()->flatten()->unique()->sort()->values();
        }

        return response()->json(['data' => $groups]);
    }

    public function show(string $slug): PublicProductResource
    {
        $product = $this->visibleProducts()->where('slug', $slug)
            ->with(['brand:id,name,slug,logo_path', 'categories:id,name,slug', 'medicalDetails', 'images' => fn ($query) => $query->orderBy('is_primary', 'desc')->orderBy('sort_order')->orderBy('id'), 'variants' => fn ($query) => $query->where('status', 'active')->whereHas('inventory')->orderBy('id')->with(['inventory', 'values.attribute'])])
            ->firstOrFail();

        return new PublicProductResource($product);
    }

    private function visibleProducts(): Builder
    {
        return Product::forStorefront();
    }
}
