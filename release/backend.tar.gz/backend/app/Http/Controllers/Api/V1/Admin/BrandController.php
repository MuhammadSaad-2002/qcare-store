<?php

namespace App\Http\Controllers\Api\V1\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\AdminDirectoryRequest;
use App\Http\Requests\Catalog\BrandRequest;
use App\Models\Brand;
use App\Support\ApiException;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\Storage;

class BrandController extends Controller
{
    public function index(AdminDirectoryRequest $request): JsonResponse
    {
        $query = Brand::query()->withCount('products');
        if ($request->filled('q')) {
            $search = '%'.$request->validated('q').'%';
            $query->where(fn (Builder $query) => $query->where('name', 'like', $search)->orWhere('slug', 'like', $search));
        }
        if ($request->filled('status')) {
            $query->where('is_active', $request->validated('status') === 'active');
        }
        $brands = $query->orderBy('name')->orderBy('id')->paginate($request->integer('per_page', 20));

        return response()->json(['data' => $brands->items(), 'meta' => [
            'currentPage' => $brands->currentPage(), 'lastPage' => $brands->lastPage(), 'total' => $brands->total(),
        ]]);
    }

    public function store(BrandRequest $request): JsonResponse
    {
        $path = $request->file('logo')?->store('brands', 'public');
        try {
            $brand = Brand::create([...$request->safe()->except('logo', 'remove_logo'), 'logo_path' => $path]);
        } catch (\Throwable $exception) {
            if ($path) {
                Storage::disk('public')->delete($path);
            }
            throw $exception;
        }

        return response()->json(['data' => $brand], 201);
    }

    public function show(Brand $brand): JsonResponse
    {
        return response()->json(['data' => $brand]);
    }

    public function update(BrandRequest $request, Brand $brand): JsonResponse
    {
        $path = $request->file('logo')?->store('brands', 'public');
        $oldPath = $brand->logo_path;
        $removeLogo = $request->boolean('remove_logo');
        try {
            $brand->update([...$request->safe()->except('logo', 'remove_logo'), ...($path || $removeLogo ? ['logo_path' => $path] : [])]);
        } catch (\Throwable $exception) {
            if ($path) {
                Storage::disk('public')->delete($path);
            }
            throw $exception;
        }
        if (($path || $removeLogo) && $oldPath) {
            Storage::disk('public')->delete($oldPath);
        }

        return response()->json(['data' => $brand->fresh()]);
    }

    public function destroy(Brand $brand): JsonResponse
    {
        if ($brand->products()->exists()) {
            throw new ApiException('brand_in_use', 'Remove product assignments before deleting this brand.', 409);
        }
        $brand->delete();
        if ($brand->logo_path) {
            Storage::disk('public')->delete($brand->logo_path);
        }

        return response()->json(['data' => ['deleted' => true]]);
    }
}
