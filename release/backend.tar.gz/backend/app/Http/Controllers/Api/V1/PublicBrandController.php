<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Models\Brand;
use Illuminate\Http\JsonResponse;

class PublicBrandController extends Controller
{
    public function index(): JsonResponse
    {
        $brands = Brand::query()->where('is_active', true)
            ->whereHas('products', fn ($query) => $query->where('status', 'published')->where('visibility', 'public')
                ->whereHas('categories', fn ($category) => $category->where('is_active', true))
                ->whereHas('images', fn ($image) => $image->where('is_primary', true))
                ->whereHas('variants', fn ($variant) => $variant->where('status', 'active')->whereHas('inventory')))
            ->orderBy('name')->get(['id', 'name', 'slug']);

        return response()->json(['data' => $brands]);
    }
}
