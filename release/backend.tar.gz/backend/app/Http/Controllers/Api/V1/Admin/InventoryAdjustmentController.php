<?php

namespace App\Http\Controllers\Api\V1\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\Catalog\InventoryAdjustmentRequest;
use App\Models\Inventory;
use App\Models\Product;
use App\Models\ProductVariant;
use App\Support\ApiException;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class InventoryAdjustmentController extends Controller
{
    public function index(Request $request, Product $product, ProductVariant $variant): JsonResponse
    {
        $movements = $variant->movements()->latest('id')->paginate(max(1, min($request->integer('per_page', 20), 100)));

        return response()->json(['data' => $movements->items(), 'meta' => [
            'currentPage' => $movements->currentPage(), 'lastPage' => $movements->lastPage(), 'total' => $movements->total(),
        ]]);
    }

    public function store(InventoryAdjustmentRequest $request, Product $product, ProductVariant $variant): JsonResponse
    {
        $data = $request->validated();
        $movement = DB::transaction(function () use ($variant, $request, $data) {
            $inventory = Inventory::query()->where('product_variant_id', $variant->id)->lockForUpdate()->firstOrFail();
            $after = $inventory->quantity_on_hand + $data['delta'];
            if ($after < 0 || $after > 4294967295) {
                throw new ApiException('invalid_stock_adjustment', 'The adjustment would make stock quantity invalid.', 422);
            }
            $before = $inventory->quantity_on_hand;
            $inventory->update(['quantity_on_hand' => $after]);

            return $variant->movements()->create([
                'user_id' => $request->user()->id,
                'delta' => $data['delta'],
                'quantity_before' => $before,
                'quantity_after' => $after,
                'reason' => $data['reason'],
            ]);
        });

        return response()->json(['data' => $movement], 201);
    }
}
