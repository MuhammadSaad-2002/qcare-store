<?php

namespace App\Http\Controllers\Api\V1\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\UpdateOrderRequest;
use App\Models\Order;
use App\Models\ProductVariant;
use App\Services\OrderUpdateService;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\Rule;

class OrderController extends Controller
{
    private const STATUSES = ['pending', 'confirmed', 'processing', 'prescription_review', 'ready', 'shipped', 'out_for_delivery', 'delivered', 'cancelled', 'refunded'];

    public function index(Request $request): JsonResponse
    {
        $input = $request->validate([
            'q' => ['sometimes', 'string', 'max:100'],
            'status' => ['sometimes', Rule::in(self::STATUSES)],
            'payment_status' => ['sometimes', Rule::in(['pending', 'paid', 'failed', 'refunded'])],
            'from' => ['sometimes', 'date_format:Y-m-d'],
            'to' => ['sometimes', 'date_format:Y-m-d', 'after_or_equal:from'],
            'per_page' => ['sometimes', 'integer', Rule::in([8, 16, 24, 48])],
            'page' => ['sometimes', 'integer', 'min:1'],
        ]);

        $query = Order::query();
        if (! empty($input['q'])) {
            $term = '%'.addcslashes($input['q'], '%_\\').'%';
            $query->where(fn (Builder $query) => $query->where('order_number', 'like', $term)
                ->orWhere('customer_name', 'like', $term)
                ->orWhere('customer_email', 'like', $term));
        }
        foreach (['status', 'payment_status'] as $field) {
            if (isset($input[$field])) {
                $query->where($field, $input[$field]);
            }
        }
        if (isset($input['from'])) {
            $query->whereDate('placed_at', '>=', $input['from']);
        }
        if (isset($input['to'])) {
            $query->whereDate('placed_at', '<=', $input['to']);
        }
        $orders = $query->orderByDesc('placed_at')->orderByDesc('id')->paginate($input['per_page'] ?? 8);

        return response()->json(['data' => $orders->getCollection()->map(fn (Order $order) => $this->summary($order)), 'meta' => [
            'currentPage' => $orders->currentPage(), 'lastPage' => $orders->lastPage(), 'total' => $orders->total(),
        ]]);
    }

    public function counts(): JsonResponse
    {
        $counts = Order::query()->select('status', DB::raw('COUNT(*) as total'))->groupBy('status')->pluck('total', 'status');

        return response()->json(['data' => [
            'total' => (int) $counts->sum(),
            'pending' => (int) ($counts['pending'] ?? 0),
            'processing' => (int) (($counts['confirmed'] ?? 0) + ($counts['processing'] ?? 0) + ($counts['prescription_review'] ?? 0) + ($counts['ready'] ?? 0)),
            'inTransit' => (int) (($counts['shipped'] ?? 0) + ($counts['out_for_delivery'] ?? 0)),
            'delivered' => (int) ($counts['delivered'] ?? 0),
            'cancelled' => (int) ($counts['cancelled'] ?? 0),
            'refunded' => (int) ($counts['refunded'] ?? 0),
        ]]);
    }

    public function productOptions(Request $request): JsonResponse
    {
        $input = $request->validate([
            'q' => ['sometimes', 'string', 'max:100'],
            'currency' => ['required', 'string', 'size:3', 'regex:/^[A-Z]{3}$/'],
        ]);
        $variants = ProductVariant::query()->with(['product:id,name,status,visibility', 'inventory', 'values.attribute'])
            ->where('status', 'active')->where('currency_code', $input['currency'])
            ->whereHas('product', fn (Builder $query) => $query->whereIn('status', ['draft', 'published']));
        if (! empty($input['q'])) {
            $term = '%'.addcslashes($input['q'], '%_\\').'%';
            $variants->where(fn (Builder $query) => $query->where('sku', 'like', $term)
                ->orWhereHas('product', fn (Builder $query) => $query->where('name', 'like', $term)));
        }

        return response()->json(['data' => $variants->orderBy('sku')->limit(20)->get()->map(fn (ProductVariant $variant) => [
            'variantPublicId' => $variant->public_id,
            'name' => $variant->product->name,
            'packSize' => $variant->values->first(fn ($value) => $value->attribute?->code === 'pack_size')?->value,
            'sku' => $variant->sku,
            'price' => $variant->sale_price !== null
                && ($variant->sale_starts_at === null || $variant->sale_starts_at->isPast())
                && ($variant->sale_ends_at === null || $variant->sale_ends_at->isFuture())
                    ? $variant->sale_price : $variant->regular_price,
            'currency' => $variant->currency_code,
            'status' => $variant->product->status,
            'stock' => $variant->inventory?->tracks_stock ? $variant->inventory->quantity_on_hand : null,
        ])]);
    }

    public function show(Order $order): JsonResponse
    {
        $order->load(['items', 'addresses', 'statusHistory' => fn ($query) => $query->with('actor:id,name')->orderByDesc('created_at')->orderByDesc('id'), 'revisions' => fn ($query) => $query->with('actor:id,name')->orderByDesc('id')]);

        return response()->json(['data' => [...$this->summary($order),
            'customerPhone' => $order->customer_phone,
            'version' => $order->version,
            'totals' => [
                'subtotal' => $order->subtotal, 'discount' => $order->discount_total,
                'tax' => $order->tax_total, 'shipping' => $order->shipping_total, 'grand' => $order->grand_total,
            ],
            'items' => $order->items->map(fn ($item) => [
                'id' => $item->id, 'name' => $item->product_name, 'sku' => $item->variant_sku,
                'quantity' => $item->quantity, 'unitPrice' => $item->unit_price, 'lineTotal' => $item->line_total,
            ]),
            'addresses' => $order->addresses->map(fn ($address) => [
                'type' => $address->type, 'recipientName' => $address->recipient_name, 'phone' => $address->phone,
                'line1' => $address->line_1, 'line2' => $address->line_2, 'area' => $address->area,
                'city' => $address->city, 'region' => $address->region, 'postalCode' => $address->postal_code,
                'countryCode' => $address->country_code, 'deliveryNotes' => $address->delivery_notes,
            ]),
            'activity' => $order->statusHistory->map(fn ($history) => [
                'id' => $history->id, 'fromStatus' => $history->from_status, 'toStatus' => $history->to_status,
                'note' => $history->note, 'actor' => $history->actor?->name, 'createdAt' => $history->created_at?->toIso8601String(),
            ]),
            'revisions' => $order->revisions->map(fn ($revision) => [
                'id' => $revision->id, 'version' => $revision->version_after,
                'changes' => $revision->changes, 'note' => $revision->note,
                'actor' => $revision->actor?->name, 'createdAt' => $revision->created_at?->toIso8601String(),
            ]),
        ]]);
    }

    public function showByPublicId(string $publicId): JsonResponse
    {
        return $this->show(Order::query()->where('public_id', $publicId)->firstOrFail());
    }

    public function update(UpdateOrderRequest $request, Order $order, OrderUpdateService $updates): JsonResponse
    {
        return $this->show($updates->update($order, $request->validated(), $request->user()));
    }

    public function updateByPublicId(UpdateOrderRequest $request, string $publicId, OrderUpdateService $updates): JsonResponse
    {
        return $this->show($updates->update(Order::query()->where('public_id', $publicId)->firstOrFail(), $request->validated(), $request->user()));
    }

    private function summary(Order $order): array
    {
        return [
            'id' => $order->id, 'publicId' => $order->public_id, 'number' => $order->order_number, 'placedAt' => $order->placed_at?->toIso8601String(),
            'customerName' => $order->customer_name, 'customerEmail' => $order->customer_email,
            'amount' => $order->grand_total, 'currency' => $order->currency_code,
            'status' => $order->status, 'paymentStatus' => $order->payment_status,
        ];
    }
}
