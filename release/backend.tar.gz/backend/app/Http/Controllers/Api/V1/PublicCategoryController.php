<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Models\Product;
use App\Support\CategoryTree;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\DB;

class PublicCategoryController extends Controller
{
    public function index(): JsonResponse
    {
        $categories = CategoryTree::active();
        $byId = $categories->keyBy('id');
        $members = DB::table('category_product')->whereIn('category_id', $categories->modelKeys())
            ->whereIn('product_id', Product::forStorefront($categories->modelKeys())->select('products.id'))->get(['category_id', 'product_id']);
        $productIds = [];
        foreach ($members as $member) {
            $category = $byId->get($member->category_id);
            while ($category) {
                $productIds[$category->id][$member->product_id] = true;
                $category = $byId->get($category->parent_id);
            }
        }
        $data = $categories->map(fn ($category): array => [
            ...$category->only(['id', 'parent_id', 'name', 'slug', 'description', 'image_path']),
            'products_count' => count($productIds[$category->id] ?? []),
        ]);

        return response()->json(['data' => $data]);
    }
}
