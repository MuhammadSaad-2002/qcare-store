<?php

namespace App\Http\Controllers\Api\V1\Admin;

use App\Http\Controllers\Controller;
use App\Services\AdminOverviewService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class AdminOverviewController extends Controller
{
    public function __invoke(Request $request, AdminOverviewService $overview): JsonResponse
    {
        return response()->json(['data' => $overview->get($request->user())]);
    }
}
