<?php

namespace App\Http\Controllers\Api\V1\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\Catalog\ProductIndexRequest;
use App\Http\Requests\Catalog\ProductRequest;
use App\Http\Resources\ProductListResource;
use App\Http\Resources\ProductResource;
use App\Models\Product;
use App\Services\Catalog\ProductListQuery;
use App\Services\Catalog\ProductWriter;
use App\Support\ApiException;
use Illuminate\Http\JsonResponse;

class ProductController extends Controller
{
    public function index(ProductIndexRequest $request, ProductListQuery $query): JsonResponse
    {
        $products = $query->paginate($request->validated());

        return response()->json(['data' => ProductListResource::collection($products->items())->resolve(), 'meta' => [
            'currentPage' => $products->currentPage(), 'lastPage' => $products->lastPage(), 'total' => $products->total(),
        ]]);
    }

    public function store(ProductRequest $request, ProductWriter $writer): JsonResponse
    {
        $product = $writer->create($request->validated());

        return (new ProductResource($product))->response()->setStatusCode(201);
    }

    public function show(Product $product): ProductResource
    {
        return new ProductResource($product->load(['categories', 'brand', 'medicalDetails', 'variants.inventory', 'variants.values', 'images']));
    }

    public function showByPublicId(string $publicId): ProductResource
    {
        return $this->show(Product::query()->where('public_id', $publicId)->firstOrFail());
    }

    public function update(ProductRequest $request, Product $product, ProductWriter $writer): ProductResource
    {
        return new ProductResource($writer->update($product, $request->validated()));
    }

    public function destroy(Product $product): JsonResponse
    {
        if ($product->status === 'published') {
            throw new ApiException('product_published', 'Unpublish this product before archiving it.', 409);
        }
        $product->update(['status' => 'archived']);
        $product->delete();

        return response()->json(['data' => ['archived' => true]]);
    }
}
