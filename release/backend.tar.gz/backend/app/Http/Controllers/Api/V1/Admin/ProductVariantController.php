<?php

namespace App\Http\Controllers\Api\V1\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\Catalog\ProductVariantRequest;
use App\Models\Product;
use App\Models\ProductVariant;
use App\Services\Catalog\PublicationGuard;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\DB;

class ProductVariantController extends Controller
{
    public function store(ProductVariantRequest $request, Product $product, PublicationGuard $guard): JsonResponse
    {
        $data = $request->validated();
        $variant = DB::transaction(function () use ($product, $data, $guard): ProductVariant {
            $variant = $product->variants()->create(collect($data)->except(['inventory', 'value_ids'])->all());
            $variant->values()->sync($data['value_ids']);
            $variant->inventory()->create($data['inventory']);
            if ($product->status === 'published') {
                $guard->assertCanPublish($product);
            }

            return $variant->load(['values', 'inventory']);
        });

        return response()->json(['data' => $variant], 201);
    }

    public function update(ProductVariantRequest $request, Product $product, ProductVariant $variant, PublicationGuard $guard): JsonResponse
    {
        $data = $request->validated();
        DB::transaction(function () use ($variant, $product, $data, $guard): void {
            $variant->update(collect($data)->except(['inventory', 'value_ids'])->all());
            $variant->values()->sync($data['value_ids']);
            if ($product->status === 'published') {
                $guard->assertCanPublish($product);
            }
        });

        return response()->json(['data' => $variant->fresh()->load(['values', 'inventory'])]);
    }

    public function destroy(Product $product, ProductVariant $variant, PublicationGuard $guard): JsonResponse
    {
        DB::transaction(function () use ($product, $variant, $guard): void {
            $variant->delete();
            if ($product->status === 'published') {
                $guard->assertCanPublish($product);
            }
        });

        return response()->json(['data' => ['deleted' => true]]);
    }
}
