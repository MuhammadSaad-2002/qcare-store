<?php

namespace App\Http\Controllers\Api\V1\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\UpdateStoreSettingsRequest;
use App\Services\StoreSettingsService;
use Illuminate\Http\JsonResponse;

class StoreSettingsController extends Controller
{
    public function show(StoreSettingsService $settings): JsonResponse
    {
        return response()->json(['data' => $settings->get()]);
    }

    public function update(UpdateStoreSettingsRequest $request, StoreSettingsService $settings): JsonResponse
    {
        return response()->json(['data' => $settings->update(
            $request->validated('values'),
            $request->validated('version'),
            $request->user(),
        )]);
    }
}
