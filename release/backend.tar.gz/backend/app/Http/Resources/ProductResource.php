<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class ProductResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        return [
            'id' => $this->id,
            'publicId' => $this->public_id,
            'name' => $this->name,
            'slug' => $this->slug,
            'kind' => $this->kind,
            'diseaseTags' => $this->disease_tags ?? [],
            'useTags' => $this->use_tags ?? [],
            'productTypeTags' => $this->product_type_tags ?? [],
            'status' => $this->status,
            'visibility' => $this->visibility,
            'summary' => $this->summary,
            'description' => $this->description,
            'isFeatured' => $this->is_featured,
            'brandId' => $this->brand_id,
            'categories' => $this->whenLoaded('categories'),
            'brand' => $this->whenLoaded('brand'),
            'medical' => $this->whenLoaded('medicalDetails'),
            'variants' => $this->whenLoaded('variants'),
            'images' => $this->whenLoaded('images'),
        ];
    }
}
