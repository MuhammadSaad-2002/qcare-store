<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;

class ProductListResource extends ProductResource
{
    public function toArray(Request $request): array
    {
        $data = parent::toArray($request);
        unset($data['variants'], $data['images']);
        $image = $this->images->first();
        $currency = $request->input('currency') ?: ($this->currency_count === 1 ? $this->variants->first()?->currency_code : null);

        return [...$data, 'updatedAt' => $this->updated_at?->toIso8601String(), 'listing' => [
            'sku' => $this->variants->first()?->sku,
            'variantCount' => $this->variants_count,
            'thumbnail' => $image ? ['path' => $image->path, 'alt' => $image->alt_text] : null,
            'stock' => $request->user()?->can('inventory.view') && $this->untracked_count === 0 && $this->inventories_count === $this->variants_count && $this->variants_count > 0
                ? (int) $this->tracked_stock : null,
            'price' => $currency && $this->minimum_price !== null ? [
                'min' => number_format((float) $this->minimum_price, 2, '.', ''),
                'max' => number_format((float) $this->maximum_price, 2, '.', ''),
                'currency' => $currency,
            ] : null,
        ]];
    }
}
