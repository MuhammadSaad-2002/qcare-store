<?php

namespace App\Http\Resources\Api\V1;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class CustomerOrderResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {
        return [
            'number' => $this->order_number,
            'status' => $this->status,
            'payment_status' => $this->payment_status,
            'payment_method' => $this->payment_method,
            'currency_code' => $this->currency_code,
            'subtotal' => $this->subtotal,
            'shipping_total' => $this->shipping_total,
            'grand_total' => $this->grand_total,
            'placed_at' => $this->placed_at?->toIso8601String(),
            'items_count' => $this->whenCounted('items'),
            'items' => $this->whenLoaded('items', fn () => $this->items->map(fn ($item) => [
                'name' => $item->product_name,
                'sku' => $item->variant_sku,
                'quantity' => $item->quantity,
                'unit_price' => $item->unit_price,
                'line_total' => $item->line_total,
            ])),
            'shipping_address' => $this->whenLoaded('addresses', function () {
                $address = $this->addresses->firstWhere('type', 'shipping');

                return $address ? [
                    'recipient_name' => $address->recipient_name,
                    'phone' => $address->phone,
                    'line_1' => $address->line_1,
                    'line_2' => $address->line_2,
                    'area' => $address->area,
                    'city' => $address->city,
                    'region' => $address->region,
                    'postal_code' => $address->postal_code,
                    'country_code' => $address->country_code,
                ] : null;
            }),
        ];
    }
}
