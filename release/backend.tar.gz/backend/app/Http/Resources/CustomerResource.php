<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class CustomerResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        return [
            'id' => $this->id,
            'publicId' => $this->public_id,
            'name' => $this->user->name,
            'email' => $this->user->email,
            'phone' => $this->phone,
            'isActive' => $this->user->is_active,
            'countryCode' => $this->addresses->first()?->country_code ?? $this->country_code,
            'hasAvatar' => $this->avatar_path !== null,
            'joinedAt' => $this->joined_at?->toDateString(),
            'createdAt' => $this->created_at?->toIso8601String(),
        ];
    }
}
