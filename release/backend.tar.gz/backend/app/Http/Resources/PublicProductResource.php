<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;
use Illuminate\Support\Facades\Storage;

class PublicProductResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        $primaryImage = $this->images->firstWhere('is_primary', true);

        return [
            'id' => $this->id,
            'name' => $this->name,
            'slug' => $this->slug,
            'kind' => $this->kind,
            'diseaseTags' => $this->disease_tags ?? [],
            'useTags' => $this->use_tags ?? [],
            'productTypeTags' => $this->product_type_tags ?? [],
            'summary' => $this->summary,
            'description' => $this->when($request->routeIs('public.products.show'), $this->description),
            'brand' => $this->brand ? ['name' => $this->brand->name, 'slug' => $this->brand->slug, 'logoUrl' => $this->brand->logo_path ? Storage::disk('public')->url($this->brand->logo_path) : null] : null,
            'categories' => $this->whenLoaded('categories', fn () => $this->categories->map(fn ($category) => [
                'name' => $category->name,
                'slug' => $category->slug,
            ])),
            'image' => $primaryImage ? [
                'url' => Storage::disk('public')->url($primaryImage->path),
                'alt' => $primaryImage->alt_text ?? $this->name,
            ] : null,
            'images' => $this->when($request->routeIs('public.products.show'), fn () => $this->images->map(fn ($image): array => [
                'url' => Storage::disk('public')->url($image->path),
                'alt' => $image->alt_text ?? $this->name,
            ])->values()),
            'variants' => $this->variants->map(fn ($variant) => [
                'id' => $variant->id,
                'sku' => $variant->sku,
                'regularPrice' => $variant->regular_price,
                'salePrice' => $variant->sale_price !== null &&
                    ($variant->sale_starts_at === null || $variant->sale_starts_at->isPast()) &&
                    ($variant->sale_ends_at === null || $variant->sale_ends_at->isFuture()) ? $variant->sale_price : null,
                'currencyCode' => $variant->currency_code,
                'inStock' => ! $variant->inventory->tracks_stock || $variant->inventory->quantity_on_hand > 0 || $variant->inventory->allows_backorder,
                'attributes' => $variant->values->map(fn ($value) => ['name' => $value->attribute->name, 'value' => $value->value]),
            ]),
            'medical' => $this->whenLoaded('medicalDetails', fn () => $this->medicalDetails ? [
                'genericName' => $this->medicalDetails->generic_name,
                'activeIngredients' => $this->medicalDetails->active_ingredients,
                'dosageForm' => $this->medicalDetails->dosage_form,
                'requiresPrescription' => $this->medicalDetails->requires_prescription,
                'isOtc' => $this->medicalDetails->is_otc,
                'information' => $this->medicalDetails->information,
            ] : null),
        ];
    }
}
