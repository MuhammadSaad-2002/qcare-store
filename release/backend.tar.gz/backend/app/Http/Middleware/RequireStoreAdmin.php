<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class RequireStoreAdmin
{
    public function handle(Request $request, Closure $next): Response
    {
        if (! config('storefront.admin_only')) {
            return $next($request);
        }

        $path = '/'.trim($request->path(), '/');
        $allowed = match ($request->method()) {
            'GET', 'HEAD' => in_array($path, ['/admin/login', '/sanctum/csrf-cookie'], true),
            'POST' => in_array($path, ['/api/v1/admin/auth/login', '/api/v1/auth/logout'], true),
            default => false,
        };
        $user = $request->user('web');

        if ($path === '/robots.txt') {
            $response = response("User-agent: *\nDisallow: /\n", 200, ['Content-Type' => 'text/plain']);
        } elseif ($allowed || ($user && $user->is_active && $user->can('admin.access'))) {
            $response = $next($request);
        } elseif ($request->is('api/*') || $request->expectsJson()) {
            $response = response()->json(['error' => [
                'code' => 'store_admin_only',
                'message' => 'The store is temporarily restricted to administrators. Please sign in with an admin account.',
            ]], $user ? 403 : 401);
        } else {
            $response = redirect('/admin/login');
        }

        $response->headers->set('Cache-Control', 'private, no-store, max-age=0');
        $response->headers->set('X-Robots-Tag', 'noindex, nofollow');
        $response->headers->set('X-QCare-Admin-Only', '1');

        return $response;
    }
}
