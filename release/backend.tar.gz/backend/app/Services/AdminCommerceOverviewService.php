<?php

namespace App\Services;

use App\Models\Order;
use App\Models\OrderAddress;
use App\Models\User;

class AdminCommerceOverviewService
{
    public function get(User $user): ?array
    {
        if (! $user->can('orders.view')) {
            return null;
        }

        $now = now('Asia/Karachi');
        $today = $now->copy()->startOfDay()->utc();
        $tomorrow = $now->copy()->addDay()->startOfDay()->utc();
        $yesterday = $today->copy()->subDay();
        $since = $now->copy()->subDays(29)->startOfDay()->utc();
        $hour = $now->copy()->subHour()->utc();
        $previousHour = $now->copy()->subHours(2)->utc();
        $valid = Order::query()->where('currency_code', 'PKR')->whereNotIn('status', ['cancelled', 'refunded']);
        $todayOrders = Order::query()->where('placed_at', '>=', $today)->where('placed_at', '<', $tomorrow);
        $yesterdayOrders = Order::query()->where('placed_at', '>=', $yesterday)->where('placed_at', '<', $today);
        $valueToday = (clone $valid)->where('placed_at', '>=', $today)->where('placed_at', '<', $tomorrow)->sum('grand_total');
        $valueYesterday = (clone $valid)->where('placed_at', '>=', $yesterday)->where('placed_at', '<', $today)->sum('grand_total');
        $period = Order::query()->where('placed_at', '>=', $since)->where('placed_at', '<=', $now->copy()->utc());
        $statuses = (clone $period)->selectRaw('status, COUNT(*) as total')->groupBy('status')->pluck('total', 'status');
        $progressed = collect(['confirmed', 'processing', 'ready', 'shipped', 'out_for_delivery', 'delivered'])->sum(fn (string $status): int => (int) ($statuses[$status] ?? 0));

        return [
            'currency' => 'PKR',
            'ordersToday' => (clone $todayOrders)->count(),
            'ordersYesterday' => $yesterdayOrders->count(),
            'pendingOrders' => Order::query()->whereIn('status', ['pending', 'prescription_review'])->count(),
            'orderValueToday' => number_format((float) $valueToday, 2, '.', ''),
            'orderValueYesterday' => number_format((float) $valueYesterday, 2, '.', ''),
            'ordersLastHour' => Order::query()->where('placed_at', '>=', $hour)->where('placed_at', '<=', $now->copy()->utc())->count(),
            'ordersPreviousHour' => Order::query()->where('placed_at', '>=', $previousHour)->where('placed_at', '<', $hour)->count(),
            'averageOrderValue' => number_format((float) ((clone $valid)->where('placed_at', '>=', $since)->where('placed_at', '<=', $now->copy()->utc())->avg('grand_total') ?? 0), 2, '.', ''),
            'pipeline' => [
                'placed' => (int) $statuses->sum(),
                'confirmed' => $progressed,
                'delivered' => (int) ($statuses['delivered'] ?? 0),
            ],
            'locations' => OrderAddress::query()->join('orders', 'orders.id', '=', 'order_addresses.order_id')
                ->where('order_addresses.type', 'shipping')->where('orders.placed_at', '>=', $since)->where('orders.placed_at', '<=', $now->copy()->utc())
                ->selectRaw('order_addresses.city, COUNT(*) as total')->groupBy('order_addresses.city')->orderByDesc('total')->orderBy('order_addresses.city')->limit(5)
                ->get()->map(fn ($location): array => ['city' => $location->city, 'count' => (int) $location->total]),
            'recentOrders' => Order::query()->latest('placed_at')->latest('id')->limit(10)
                ->get(['id', 'public_id', 'order_number', 'customer_name', 'grand_total', 'currency_code', 'status', 'placed_at'])
                ->map(fn (Order $order): array => [
                    'publicId' => $order->public_id,
                    'number' => $order->order_number,
                    'customerName' => $order->customer_name,
                    'amount' => $order->grand_total,
                    'currency' => $order->currency_code,
                    'status' => $order->status,
                    'placedAt' => $order->placed_at->toIso8601String(),
                ]),
        ];
    }
}
