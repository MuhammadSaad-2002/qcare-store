<?php

namespace App\Services;

use App\Models\Setting;
use App\Models\SettingChange;
use App\Models\User;
use App\Support\ApiException;
use Illuminate\Support\Facades\DB;

class StoreSettingsService
{
    private const FIELDS = [
        'siteName' => 'site.name',
        'email' => 'contact.email',
        'phone' => 'contact.phone',
        'whatsapp' => 'contact.whatsapp',
        'address' => 'business.address',
        'hours' => 'business.hours',
    ];

    public function get(): array
    {
        return DB::transaction(fn (): array => $this->snapshot());
    }

    /** @param array<string, string|null> $values */
    public function update(array $values, string $version, User $actor): array
    {
        return DB::transaction(function () use ($values, $version, $actor): array {
            Setting::query()->where('key', 'site.name')->lockForUpdate()->firstOrFail();
            $current = $this->snapshot();

            if (! hash_equals($current['version'], $version)) {
                throw new ApiException('settings_conflict', 'Another administrator updated these settings. Reload the latest version before saving.', 409);
            }

            $changes = [];
            foreach (self::FIELDS as $field => $key) {
                $setting = Setting::firstOrNew(['key' => $key]);
                $value = $values[$field];
                if ($setting->value === $value && ($setting->is_public || ! $setting->exists)) {
                    continue;
                }

                $changes[$field] = ['before' => $setting->value, 'after' => $value, 'wasPublic' => (bool) $setting->is_public];
                $setting->fill(['group' => explode('.', $key)[0], 'value' => $value, 'is_public' => true])->save();
            }

            if ($changes !== []) {
                SettingChange::create(['user_id' => $actor->id, 'changes' => $changes]);
            }

            return $this->snapshot();
        }, 3);
    }

    private function snapshot(): array
    {
        $settings = Setting::query()->whereIn('key', self::FIELDS)->get()->keyBy('key');
        $values = [];
        $visibility = [];
        foreach (self::FIELDS as $field => $key) {
            $values[$field] = $settings->get($key)?->value;
            $visibility[$field] = (bool) $settings->get($key)?->is_public;
        }
        $lastChange = SettingChange::query()->with('user:id,name')->latest('id')->first();

        return [
            'values' => $values,
            'version' => hash('sha256', json_encode([$values, $visibility, $lastChange?->id], JSON_THROW_ON_ERROR)),
            'updatedAt' => $lastChange?->created_at?->toIso8601String(),
            'updatedBy' => $lastChange?->user?->name,
        ];
    }
}
