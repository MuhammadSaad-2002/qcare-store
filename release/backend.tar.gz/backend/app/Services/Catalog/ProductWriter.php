<?php

namespace App\Services\Catalog;

use App\Models\Product;
use Illuminate\Support\Facades\DB;

class ProductWriter
{
    public function __construct(private readonly PublicationGuard $publicationGuard) {}

    public function create(array $data): Product
    {
        return DB::transaction(function () use ($data): Product {
            $product = Product::create(collect($data)->except(['category_ids', 'medical', 'variant'])->all());
            $product->categories()->sync($data['category_ids']);
            if ($data['kind'] === 'medicine' && isset($data['medical'])) {
                $product->medicalDetails()->create($data['medical']);
            }
            $variant = $product->variants()->create([
                'sku' => $data['variant']['sku'],
                'regular_price' => $data['variant']['regular_price'],
                'currency_code' => $data['variant']['currency_code'],
                'status' => 'active',
            ]);
            $variant->inventory()->create(['quantity_on_hand' => $data['variant']['quantity_on_hand']]);

            return $product->fresh()->load(['categories', 'brand', 'medicalDetails', 'variants.inventory', 'images']);
        });
    }

    public function update(Product $product, array $data): Product
    {
        return DB::transaction(function () use ($product, $data): Product {
            $product->update(collect($data)->except(['category_ids', 'medical'])->all());
            $product->categories()->sync($data['category_ids']);
            if ($data['kind'] === 'medicine') {
                if (isset($data['medical'])) {
                    $product->medicalDetails()->updateOrCreate([], $data['medical']);
                }
            } else {
                $product->medicalDetails()->delete();
            }
            $product->unsetRelation('medicalDetails');
            if ($product->status === 'published') {
                $this->publicationGuard->assertCanPublish($product);
            }

            return $product->fresh()->load(['categories', 'brand', 'medicalDetails', 'variants.inventory', 'images']);
        });
    }
}
