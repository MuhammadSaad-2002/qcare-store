<?php

namespace App\Services\Catalog;

use App\Models\Category;
use App\Models\Product;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;
use RuntimeException;

class StorefrontHierarchy
{
    public function arrange(bool $dryRun = false): array
    {
        $definitions = config('storefront-catalog.categories');
        $managedSlugs = array_column($definitions, 0);
        $products = Product::with(['categories', 'images'])->orderBy('id')->get();
        $assignments = [];
        foreach ($products as $product) {
            $matched = [];
            foreach ($definitions as [$slug, $name, $parent, $rule]) {
                if (($parent === null || isset($matched[$parent])) && $this->matches($product, $rule)) {
                    $matched[$slug] = true;
                }
            }
            $custom = $product->categories->pluck('slug')->diff($managedSlugs)->all();
            $assignments[$product->id] = array_values(array_unique([...array_keys($matched), ...$custom]));
            if ($assignments[$product->id] === []) {
                throw new RuntimeException('Product has no reviewed category: '.$product->name);
            }
        }
        $existing = Category::get()->keyBy('slug');
        $categoryChanges = [];
        $desired = [];
        foreach ($definitions as $index => [$slug, $name, $parent]) {
            $category = $existing->get($slug);
            $image = $category?->image_path;
            if (! $image) {
                $example = $products->first(fn (Product $product): bool => in_array($slug, $assignments[$product->id], true) && $product->images->contains('is_primary', true));
                $image = $example?->images->firstWhere('is_primary', true)?->path ?? ($parent ? ($desired[$parent]['image_path'] ?? null) : null);
            }
            $desired[$slug] = [
                'name' => $name, 'parent_slug' => $parent, 'image_path' => $image,
                'description' => 'Browse '.$name.' at Q Care Pharmacy. Compare pack contents, prices and availability for delivery across Pakistan.',
                'sort_order' => $index, 'seo_title' => $name.' | Q Care Pharmacy',
                'seo_description' => 'Shop '.$name.' at Q Care Pharmacy. View clear pack details and current prices, with local Bahria Town delivery and courier delivery across Pakistan.',
            ];
            $before = $category ? [...$category->only(['name', 'image_path', 'description', 'sort_order', 'seo_title', 'seo_description']), 'parent_slug' => $existing->firstWhere('id', $category->parent_id)?->slug] : null;
            if ($before === null || $before != $desired[$slug]) {
                $categoryChanges[] = ['slug' => $slug, 'before' => $before, 'after' => $desired[$slug]];
            }
        }
        $productChanges = [];
        foreach ($products as $product) {
            $before = $product->categories->pluck('slug')->sort()->values()->all();
            $after = $assignments[$product->id];
            sort($after);
            if ($before !== $after) {
                $productChanges[] = ['product_id' => $product->id, 'name' => $product->name, 'before' => $before, 'after' => $after];
            }
        }
        $report = ['reviewed_at' => now()->toIso8601String(), 'products_reviewed' => $products->count(), 'category_changes' => $categoryChanges, 'product_changes' => $productChanges];
        if ($dryRun || ($categoryChanges === [] && $productChanges === [])) {
            return $report;
        }
        DB::transaction(function () use ($desired, $existing, $products, $assignments, $productChanges, $report): void {
            $ids = $existing->map->id->all();
            foreach ($desired as $slug => $values) {
                $parent = $values['parent_slug'];
                unset($values['parent_slug']);
                $category = Category::updateOrCreate(['slug' => $slug], [...$values, 'parent_id' => $parent ? $ids[$parent] : null, 'is_active' => $existing->get($slug)?->is_active ?? true]);
                $ids[$slug] = $category->id;
            }
            foreach ($productChanges as $change) {
                $products->firstWhere('id', $change['product_id'])->categories()->sync(array_map(fn (string $slug): int => $ids[$slug], $assignments[$change['product_id']]));
            }
            if (! Storage::disk('local')->put('catalog-hierarchy/'.now()->format('Ymd-His').'-'.Str::uuid().'.json', json_encode($report, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR))) {
                throw new RuntimeException('Could not save the catalog hierarchy audit.');
            }
        });

        return $report;
    }

    private function matches(Product $product, array $rule): bool
    {
        if (isset($rule['kind']) && $product->kind !== $rule['kind']) {
            return false;
        }
        if (isset($rule['name_pattern'])) {
            return preg_match($rule['name_pattern'], $product->name) === 1;
        }
        $groups = ['categories' => $product->categories->pluck('slug')->all(), 'disease' => $product->disease_tags ?? [], 'use' => $product->use_tags ?? [], 'type' => $product->product_type_tags ?? []];
        $hasOptions = false;
        foreach ($groups as $key => $values) {
            if (isset($rule[$key])) {
                $hasOptions = true;
                if (array_intersect($rule[$key], $values) !== []) {
                    return true;
                }
            }
        }

        return ! $hasOptions;
    }
}
