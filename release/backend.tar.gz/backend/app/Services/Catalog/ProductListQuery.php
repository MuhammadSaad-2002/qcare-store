<?php

namespace App\Services\Catalog;

use App\Models\Product;
use App\Models\ProductVariant;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;
use Illuminate\Database\Eloquent\Builder;

class ProductListQuery
{
    /** @param array<string, mixed> $filters */
    public function paginate(array $filters): LengthAwarePaginator
    {
        $currency = $filters['currency'] ?? null;
        $currencyScope = fn (Builder $query): Builder => $query->when($currency, fn (Builder $query): Builder => $query->where('currency_code', $currency));
        $query = Product::query()->with([
            'brand:id,name', 'categories:id,name,slug',
            'variants' => fn ($query) => $query->select('id', 'product_id', 'sku', 'currency_code')->orderBy('id')->limit(1),
            'images' => fn ($query) => $query->orderByDesc('is_primary')->orderBy('sort_order')->orderBy('id')->limit(1),
        ])->withCount(['variants', 'inventories', 'inventories as untracked_count' => fn (Builder $query) => $query->where('tracks_stock', false)])
            ->withSum(['inventories as tracked_stock' => fn (Builder $query) => $query->where('tracks_stock', true)], 'quantity_on_hand')
            ->withMin(['variants as minimum_price' => $currencyScope], 'regular_price')
            ->withMax(['variants as maximum_price' => $currencyScope], 'regular_price')
            ->addSelect(['currency_count' => ProductVariant::selectRaw('COUNT(DISTINCT currency_code)')->whereColumn('product_id', 'products.id')]);

        if (($filters['status'] ?? null) === 'archived') {
            $query->withTrashed();
        }
        if (! empty($filters['status'])) {
            $query->where('status', $filters['status']);
        }
        if (! empty($filters['category'])) {
            $query->whereHas('categories', fn (Builder $query) => $query->where('categories.id', $filters['category']));
        }
        if (! empty($filters['q'])) {
            $term = '%'.$filters['q'].'%';
            $query->where(fn (Builder $query) => $query->where('name', 'like', $term)->orWhereHas('variants', fn (Builder $query) => $query->where('sku', 'like', $term)));
        }
        if ($currency || isset($filters['min_price']) || isset($filters['max_price'])) {
            $query->whereHas('variants', function (Builder $query) use ($filters, $currency): void {
                if ($currency) {
                    $query->where('currency_code', $currency);
                }
                if (isset($filters['min_price'])) {
                    $query->where('regular_price', '>=', $filters['min_price']);
                }
                if (isset($filters['max_price'])) {
                    $query->where('regular_price', '<=', $filters['max_price']);
                }
            });
        }

        match ($filters['sort'] ?? 'updated_desc') {
            'name_asc' => $query->orderBy('name'),
            'name_desc' => $query->orderByDesc('name'),
            default => $query->orderByDesc('updated_at'),
        };

        return $query->orderByDesc('id')->paginate($filters['per_page'] ?? 8);
    }
}
