<?php

namespace App\Services\Catalog;

use App\Models\Product;
use App\Support\ApiException;

class PublicationGuard
{
    public function assertCanPublish(Product $product): void
    {
        if ($product->visibility !== 'public') {
            throw new ApiException('publication_blocked', 'Set product visibility to public before publishing.', 422);
        }
        if (! $product->categories()->where('is_active', true)->exists()) {
            throw new ApiException('publication_blocked', 'Assign an active category before publishing.', 422);
        }
        if (! $product->images()->where('is_primary', true)->exists()) {
            throw new ApiException('publication_blocked', 'Add a primary image before publishing.', 422);
        }
        if (! $product->variants()->where('status', 'active')->whereHas('inventory')->exists()) {
            throw new ApiException('publication_blocked', 'Add an active sellable variant with inventory before publishing.', 422);
        }
        if ($product->kind === 'medicine') {
            $medical = $product->medicalDetails;
            if ($medical === null || $medical->requires_prescription === null || $medical->is_otc === null) {
                throw new ApiException('prescription_decision_required', 'Set prescription requirement and OTC status before publishing a medicine.', 422);
            }
            if ($medical->requires_prescription && $medical->is_otc) {
                throw new ApiException('publication_blocked', 'A prescription medicine cannot be marked OTC.', 422);
            }
        }
    }
}
