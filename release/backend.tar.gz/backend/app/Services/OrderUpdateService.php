<?php

namespace App\Services;

use App\Models\Order;
use App\Models\ProductVariant;
use App\Models\User;
use App\Support\ApiException;
use Illuminate\Support\Facades\DB;

class OrderUpdateService
{
    private const ADDRESS_FIELDS = ['recipient_name', 'phone', 'line_1', 'line_2', 'area', 'city', 'region', 'postal_code', 'country_code', 'delivery_notes'];

    private const MAX_CENTS = 999999999999;

    public function update(Order $order, array $input, User $actor): Order
    {
        return DB::transaction(function () use ($order, $input, $actor): Order {
            $order = Order::query()->whereKey($order->id)->lockForUpdate()->firstOrFail();
            if ($order->version !== $input['version']) {
                throw new ApiException('order_conflict', 'This order changed since you opened it. Reload the latest version before saving.', 409);
            }

            $changes = [];
            $previousStatus = $order->status;
            if ($input['status'] !== $previousStatus) {
                if ($input['status'] === 'refunded' || $previousStatus === 'refunded') {
                    throw new ApiException('refund_workflow_required', 'Refund status changes require the refund workflow.', 422);
                }
                $changes['status'] = ['before' => $previousStatus, 'after' => $input['status']];
                $order->status = $input['status'];
            }

            if (isset($input['payment_status']) && $input['payment_status'] !== $order->payment_status) {
                if ($input['payment_status'] === 'refunded' || $order->payment_status === 'refunded') {
                    throw new ApiException('refund_workflow_required', 'Refund status changes require the refund workflow.', 422);
                }
                $changes['payment_status'] = ['before' => $order->payment_status, 'after' => $input['payment_status']];
                $order->payment_status = $input['payment_status'];
            }

            foreach (['shipping', 'billing'] as $type) {
                if (isset($input[$type])) {
                    $this->updateAddress($order, $type, $input[$type], $changes);
                }
            }

            if (isset($input['items'])) {
                $this->updateItems($order, $input['items'], $changes);
            }

            foreach (['discount_total', 'tax_total', 'shipping_total'] as $field) {
                if (isset($input[$field])) {
                    $after = self::money(self::cents($input[$field]));
                    if ($after !== $order->getAttribute($field)) {
                        $changes[$field] = ['before' => $order->getAttribute($field), 'after' => $after];
                        $order->setAttribute($field, $after);
                    }
                }
            }

            $grand = self::cents($order->subtotal) - self::cents($order->discount_total)
                + self::cents($order->tax_total) + self::cents($order->shipping_total);
            if ($grand < 0 || $grand > self::MAX_CENTS) {
                throw new ApiException('invalid_order_total', 'The order total must be between zero and the supported maximum.', 422);
            }
            $grandValue = self::money($grand);
            if ($grandValue !== $order->grand_total) {
                $changes['grand_total'] = ['before' => $order->grand_total, 'after' => $grandValue];
                $order->grand_total = $grandValue;
            }

            $note = trim($input['note']);
            $order->version++;
            $order->save();
            if (isset($changes['status'])) {
                $order->statusHistory()->create([
                    'from_status' => $previousStatus,
                    'to_status' => $order->status,
                    'actor_user_id' => $actor->id,
                    'note' => $note,
                    'created_at' => now(),
                ]);
            }
            $order->revisions()->create([
                'actor_user_id' => $actor->id,
                'version_before' => $order->version - 1,
                'version_after' => $order->version,
                'changes' => $changes,
                'note' => $note,
                'created_at' => now(),
            ]);

            return $order;
        }, 3);
    }

    private function updateAddress(Order $order, string $type, array $input, array &$changes): void
    {
        $address = $order->addresses()->firstOrNew(['type' => $type]);
        foreach (self::ADDRESS_FIELDS as $field) {
            $after = $input[$field] ?? null;
            if ($field === 'country_code' && $after !== null) {
                $after = strtoupper($after);
            }
            $before = $address->getAttribute($field);
            if ($before !== $after) {
                $changes[$type.'.'.$field] = ['before' => $before, 'after' => $after];
                $address->setAttribute($field, $after);
            }
        }
        if ($address->isDirty()) {
            $address->save();
        }
    }

    private function updateItems(Order $order, array $input, array &$changes): void
    {
        $existing = $order->items()->orderBy('id')->lockForUpdate()->get()->keyBy('id');
        $before = $existing->values()->map(fn ($item) => self::itemSnapshot($item))->all();
        $submittedIds = [];
        $submittedVariants = [];
        $subtotal = 0;

        foreach ($input as $line) {
            if (isset($line['id']) === isset($line['variant_public_id'])) {
                throw new ApiException('invalid_order_item', 'Each order line must reference one existing line or one catalog variant.', 422);
            }
            if (isset($line['id'])) {
                $item = $existing->get($line['id']);
                if (! $item || isset($submittedIds[$item->id])) {
                    throw new ApiException('invalid_order_item', 'An order line is missing, duplicated, or belongs to another order.', 422);
                }
                $submittedIds[$item->id] = true;
            } else {
                $variant = ProductVariant::query()->with(['product', 'values.attribute'])->where('public_id', $line['variant_public_id'])->first();
                if (! $variant || $variant->status !== 'active' || ! in_array($variant->product?->status, ['draft', 'published'], true)
                    || $variant->currency_code !== $order->currency_code) {
                    throw new ApiException('invalid_order_item', 'Choose an active catalog variant in the order currency.', 422);
                }
                $packSize = $variant->values->first(fn ($value) => $value->attribute?->code === 'pack_size')?->value;
                $item = $order->items()->make([
                    'product_id' => $variant->product_id,
                    'product_variant_id' => $variant->id,
                    'product_name' => $variant->product->name.($packSize ? " (Pack of {$packSize})" : ''),
                    'variant_sku' => $variant->sku,
                ]);
            }
            if ($item->product_variant_id && isset($submittedVariants[$item->product_variant_id])) {
                throw new ApiException('duplicate_order_item', 'Combine duplicate product variants into one order line.', 422);
            }
            if ($item->product_variant_id) {
                $submittedVariants[$item->product_variant_id] = true;
            }
            $lineTotal = self::cents($line['unit_price']) * (int) $line['quantity'];
            $subtotal += $lineTotal;
            if ($lineTotal > self::MAX_CENTS || $subtotal > self::MAX_CENTS) {
                throw new ApiException('invalid_order_total', 'The order total exceeds the supported maximum.', 422);
            }
            $item->quantity = $line['quantity'];
            $item->unit_price = self::money(self::cents($line['unit_price']));
            $item->line_total = self::money($lineTotal);
            $item->save();
        }

        $order->items()->whereNotIn('id', array_keys($submittedIds))
            ->whereIn('id', $existing->keys()->all())->delete();
        $after = $order->items()->orderBy('id')->get()->map(fn ($item) => self::itemSnapshot($item))->all();
        if ($before !== $after) {
            $changes['items'] = ['before' => $before, 'after' => $after];
        }
        $subtotalValue = self::money($subtotal);
        if ($subtotalValue !== $order->subtotal) {
            $changes['subtotal'] = ['before' => $order->subtotal, 'after' => $subtotalValue];
            $order->subtotal = $subtotalValue;
        }
    }

    private static function itemSnapshot($item): array
    {
        return [
            'name' => $item->product_name,
            'sku' => $item->variant_sku,
            'quantity' => (int) $item->quantity,
            'unitPrice' => $item->unit_price,
            'lineTotal' => $item->line_total,
        ];
    }

    private static function cents(string|int|float $value): int
    {
        [$whole, $fraction] = array_pad(explode('.', (string) $value, 2), 2, '');

        return ((int) $whole * 100) + (int) str_pad(substr($fraction, 0, 2), 2, '0');
    }

    private static function money(int $cents): string
    {
        return intdiv($cents, 100).'.'.str_pad((string) ($cents % 100), 2, '0', STR_PAD_LEFT);
    }
}
