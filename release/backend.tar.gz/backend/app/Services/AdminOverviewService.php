<?php

namespace App\Services;

use App\Models\Brand;
use App\Models\Category;
use App\Models\Customer;
use App\Models\Inventory;
use App\Models\Product;
use App\Models\User;

class AdminOverviewService
{
    public function get(User $user): array
    {
        $catalog = null;
        $inventory = null;

        if ($user->can('catalog.view')) {
            $today = now('UTC')->startOfDay();
            $daily = Product::query()->whereBetween('created_at', [$today->copy()->subDays(6), $today->copy()->endOfDay()])
                ->selectRaw('DATE(created_at) as day, COUNT(*) as total')->groupBy('day')->pluck('total', 'day');
            $catalog = [
                'dailyCreated' => collect(range(6, 0))->map(fn (int $days): array => [
                    'date' => $today->copy()->subDays($days)->toDateString(),
                    'count' => (int) ($daily[$today->copy()->subDays($days)->toDateString()] ?? 0),
                ]),
                'totalProducts' => Product::query()->count(),
                'publishedProducts' => Product::query()->where('status', 'published')->count(),
                'draftProducts' => Product::query()->where('status', 'draft')->count(),
                'activeCategories' => Category::query()->where('is_active', true)->count(),
                'brands' => Brand::query()->count(),
                'recentProducts' => Product::query()->with(['brand:id,name', 'images' => fn ($query) => $query->orderByDesc('is_primary')->orderBy('id')->limit(1)])->latest('updated_at')->latest('id')->limit(5)
                    ->get(['id', 'public_id', 'brand_id', 'name', 'status', 'kind', 'updated_at']),
            ];
        }

        if ($user->can('inventory.view')) {
            $lowStock = Inventory::query()->where('tracks_stock', true)
                ->whereColumn('quantity_on_hand', '<=', 'low_stock_threshold')
                ->whereHas('variant.product', fn ($query) => $query->where('status', '!=', 'archived'));
            $inventory = [
                'lowStockCount' => (clone $lowStock)->count(),
                'lowStockVariants' => $lowStock->with('variant.product:id,public_id,name')->orderBy('quantity_on_hand')
                    ->limit(5)->get()->map(fn (Inventory $stock): array => [
                        'productId' => $stock->variant->product->id,
                        'productPublicId' => $stock->variant->product->public_id,
                        'productName' => $stock->variant->product->name,
                        'sku' => $stock->variant->sku,
                        'quantity' => $stock->quantity_on_hand,
                        'threshold' => $stock->low_stock_threshold,
                    ]),
            ];
        }

        return [
            'catalog' => $catalog,
            'inventory' => $inventory,
            'customers' => $user->can('customers.view') ? ['total' => Customer::query()->count()] : null,
        ];
    }
}
