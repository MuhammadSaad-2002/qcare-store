<?php

namespace App\Services;

use App\Models\Setting;

class PublicSettingsService
{
    private const KEYS = [
        'site.name', 'site.logo_url', 'contact.phone', 'contact.email',
        'contact.whatsapp', 'business.address', 'business.hours',
    ];

    public function get(): array
    {
        $values = Setting::query()
            ->where('is_public', true)
            ->whereIn('key', self::KEYS)
            ->get()
            ->mapWithKeys(fn (Setting $setting): array => [$setting->key => $setting->value]);

        return [
            'siteName' => $values->get('site.name'),
            'logoUrl' => $values->get('site.logo_url'),
            'phone' => $values->get('contact.phone'),
            'email' => $values->get('contact.email'),
            'whatsapp' => $values->get('contact.whatsapp'),
            'address' => $values->get('business.address'),
            'hours' => $values->get('business.hours'),
        ];
    }
}
