<?php

namespace App\Services;

use App\Models\Setting;
use App\Models\SettingChange;
use App\Models\User;
use App\Support\ApiException;
use Illuminate\Support\Facades\DB;

class DashboardGoalsService
{
    public function get(string $month): array
    {
        $stored = Setting::query()->where('key', 'dashboard.goals.'.$month)->first()?->value ?? [];
        $values = [
            'revenue' => $stored['revenue'] ?? null,
            'customers' => $stored['customers'] ?? null,
            'averageOrderValue' => $stored['averageOrderValue'] ?? null,
        ];

        return ['month' => $month, 'values' => $values, 'version' => hash('sha256', json_encode([$month, $values], JSON_THROW_ON_ERROR))];
    }

    public function update(string $month, array $values, string $version, User $actor): array
    {
        return DB::transaction(function () use ($month, $values, $version, $actor): array {
            Setting::query()->where('key', 'site.name')->lockForUpdate()->firstOrFail();
            $current = $this->get($month);
            if (! hash_equals($current['version'], $version)) {
                throw new ApiException('goals_conflict', 'Another administrator changed these goals. Reload the dashboard and try again.', 409);
            }
            $normalized = [
                'revenue' => $values['revenue'] === null ? null : number_format((float) $values['revenue'], 2, '.', ''),
                'customers' => $values['customers'] === null ? null : (int) $values['customers'],
                'averageOrderValue' => $values['averageOrderValue'] === null ? null : number_format((float) $values['averageOrderValue'], 2, '.', ''),
            ];
            Setting::updateOrCreate(['key' => 'dashboard.goals.'.$month], ['group' => 'dashboard', 'value' => $normalized, 'is_public' => false]);
            if ($normalized !== $current['values']) {
                SettingChange::create(['user_id' => $actor->id, 'changes' => ['dashboardGoals' => ['month' => $month, 'before' => $current['values'], 'after' => $normalized]]]);
            }

            return $this->get($month);
        }, 3);
    }
}
