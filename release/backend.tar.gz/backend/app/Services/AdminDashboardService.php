<?php

namespace App\Services;

use App\Models\Customer;
use App\Models\Inventory;
use App\Models\Order;
use App\Models\OrderAddress;
use App\Models\OrderStatusHistory;
use App\Models\User;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\DB;

class AdminDashboardService
{
    public function get(User $user, string $period): array
    {
        $now = now('Asia/Karachi');
        $days = match ($period) {
            '7d' => 7, '30d' => 30, default => 1
        };
        $startLocal = $now->copy()->startOfDay()->subDays($days - 1);
        $endLocal = $now->copy()->addDay()->startOfDay();
        $start = $startLocal->copy()->utc();
        $end = $endLocal->copy()->utc();
        $previousStart = $startLocal->copy()->subDays($days)->utc();
        $monthStart = $now->copy()->startOfMonth()->utc();
        $monthEnd = $now->copy()->addMonthNoOverflow()->startOfMonth()->utc();
        $commerce = null;
        $customers = null;
        $activity = collect();
        $monthly = ['revenue' => null, 'customers' => null, 'averageOrderValue' => null];

        if ($user->can('orders.view')) {
            $current = Order::query()->where('placed_at', '>=', $start)->where('placed_at', '<', $end);
            $previous = Order::query()->where('placed_at', '>=', $previousStart)->where('placed_at', '<', $start);
            $stats = $this->totals(clone $current);
            $prior = $this->totals($previous);
            $month = $this->totals(Order::query()->where('placed_at', '>=', $monthStart)->where('placed_at', '<', $monthEnd));
            $monthly['revenue'] = $month['revenue'];
            $monthly['averageOrderValue'] = $month['averageOrderValue'];
            $recent = (clone $current)->latest('placed_at')->latest('id')->limit(8)
                ->get(['id', 'public_id', 'order_number', 'customer_name', 'status', 'payment_status', 'grand_total', 'currency_code', 'placed_at']);
            $regionalOrders = OrderAddress::query()->join('orders', 'orders.id', '=', 'order_addresses.order_id')->where('order_addresses.type', 'shipping')
                ->where('orders.placed_at', '>=', $start)->where('orders.placed_at', '<', $end)
                ->where('orders.payment_status', 'paid')->where('orders.currency_code', 'PKR')->whereNotIn('orders.status', ['cancelled', 'refunded'])
                ->selectRaw("COALESCE(NULLIF(TRIM(order_addresses.region), ''), order_addresses.city) as region_name, orders.grand_total");
            $commerce = [
                'current' => $stats,
                'previous' => $prior,
                'pendingOrders' => Order::query()->whereIn('status', ['pending', 'prescription_review'])->count(),
                'chart' => $this->series($this->paid(clone $current), $startLocal, $days, $period === 'today'),
                'week' => $this->series($this->paid(Order::query()->where('placed_at', '>=', $now->copy()->startOfDay()->subDays(6)->utc())->where('placed_at', '<', $end)), $now->copy()->startOfDay()->subDays(6), 7, false),
                'previousWeekRevenue' => $this->money($this->paid(Order::query()->where('placed_at', '>=', $now->copy()->startOfDay()->subDays(13)->utc())->where('placed_at', '<', $now->copy()->startOfDay()->subDays(6)->utc()))->sum('grand_total')),
                'regions' => DB::query()->fromSub($regionalOrders, 'regional_orders')
                    ->selectRaw('region_name as region, SUM(grand_total) as revenue')
                    ->groupBy('region_name')->orderByDesc('revenue')->orderBy('region_name')->limit(5)->get()
                    ->map(fn ($row): array => ['name' => $row->region, 'revenue' => $this->money($row->revenue)]),
                'recentOrders' => $recent->map(fn (Order $order): array => [
                    'publicId' => $order->public_id, 'number' => $order->order_number, 'customerName' => $order->customer_name,
                    'status' => $order->status, 'paymentStatus' => $order->payment_status, 'amount' => $order->grand_total,
                    'currency' => $order->currency_code, 'placedAt' => $order->placed_at->toIso8601String(),
                ]),
            ];
            foreach ($recent->take(3) as $order) {
                $activity->push(['id' => 'order-'.$order->id, 'tone' => 'amber', 'title' => 'New order '.$order->order_number, 'detail' => $order->currency_code.' '.number_format((float) $order->grand_total, 0), 'at' => $order->placed_at->toIso8601String(), 'href' => '/admin/orders/'.$order->public_id]);
            }
            foreach (OrderStatusHistory::query()->with('order:id,public_id,order_number')->where('created_at', '>=', $start)->where('created_at', '<', $end)->latest('created_at')->limit(3)->get() as $event) {
                $activity->push(['id' => 'status-'.$event->id, 'tone' => in_array($event->to_status, ['cancelled', 'refunded']) ? 'red' : 'green', 'title' => 'Order '.$event->order->order_number, 'detail' => ucfirst(str_replace('_', ' ', $event->to_status)), 'at' => $event->created_at->toIso8601String(), 'href' => '/admin/orders/'.$event->order->public_id]);
            }
        }

        if ($user->can('customers.view')) {
            $customers = [
                'total' => Customer::query()->count(),
                'newInPeriod' => Customer::query()->where('created_at', '>=', $start)->where('created_at', '<', $end)->count(),
                'previousNew' => Customer::query()->where('created_at', '>=', $previousStart)->where('created_at', '<', $start)->count(),
            ];
            $monthly['customers'] = Customer::query()->where('created_at', '>=', $monthStart)->where('created_at', '<', $monthEnd)->count();
            foreach (Customer::query()->with('user:id,name')->where('created_at', '>=', $start)->where('created_at', '<', $end)->latest('created_at')->limit(3)->get() as $customer) {
                $activity->push(['id' => 'customer-'.$customer->id, 'tone' => 'blue', 'title' => 'New customer registered', 'detail' => $customer->user?->name ?? 'Customer', 'at' => $customer->created_at->toIso8601String(), 'href' => '/admin/customers']);
            }
        }
        if ($user->can('inventory.view')) {
            foreach (Inventory::query()->where('tracks_stock', true)->whereColumn('quantity_on_hand', '<=', 'low_stock_threshold')->where('updated_at', '>=', $start)->where('updated_at', '<', $end)
                ->whereHas('variant.product', fn ($query) => $query->where('status', '!=', 'archived'))->with('variant.product:id,public_id,name')->latest('updated_at')->limit(3)->get() as $stock) {
                $activity->push(['id' => 'stock-'.$stock->id, 'tone' => 'amber', 'title' => 'Stock alert', 'detail' => $stock->variant->product->name.' · '.$stock->quantity_on_hand.' left', 'at' => $stock->updated_at->toIso8601String(), 'href' => $user->can('catalog.view') ? '/admin/catalog/products/'.$stock->variant->product->public_id : '/admin/live-monitor#inventory-attention']);
            }
        }

        return [
            'period' => $period, 'generatedAt' => $now->toIso8601String(), 'currency' => 'PKR',
            'commerce' => $commerce, 'customers' => $customers,
            'monthly' => $monthly, 'goals' => app(DashboardGoalsService::class)->get($now->format('Y-m')),
            'activity' => $activity->sortByDesc('at')->take(5)->values(),
            'permissions' => ['manageGoals' => $user->can('settings.manage'), 'createProduct' => $user->can('catalog.manage')],
        ];
    }

    private function paid(Builder $query): Builder
    {
        return $query->where('payment_status', 'paid')->where('currency_code', 'PKR')->whereNotIn('status', ['cancelled', 'refunded']);
    }

    private function totals(Builder $query): array
    {
        $row = $query->toBase()->selectRaw("COUNT(*) as orders,
            SUM(CASE WHEN payment_status = 'paid' AND currency_code = 'PKR' AND status NOT IN ('cancelled', 'refunded') THEN grand_total ELSE 0 END) as revenue,
            AVG(CASE WHEN currency_code = 'PKR' AND status NOT IN ('cancelled', 'refunded') THEN grand_total END) as average_value,
            SUM(CASE WHEN status = 'delivered' THEN 1 ELSE 0 END) as delivered,
            SUM(CASE WHEN status NOT IN ('cancelled', 'refunded') THEN 1 ELSE 0 END) as eligible")->first();

        return ['orders' => (int) $row->orders, 'revenue' => $this->money($row->revenue), 'averageOrderValue' => $this->money($row->average_value), 'fulfilmentRate' => $row->eligible ? round($row->delivered / $row->eligible * 100, 1) : 0];
    }

    private function series(Builder $query, Carbon $start, int $days, bool $hourly): array
    {
        // Stored timestamps are UTC; Pakistan Standard Time is UTC+05:00.
        $format = $hourly ? '%Y-%m-%d %H' : '%Y-%m-%d';
        $rows = $query->selectRaw('DATE_FORMAT(DATE_ADD(placed_at, INTERVAL 5 HOUR), ?) as bucket, SUM(grand_total) as revenue', [$format])->groupBy('bucket')->pluck('revenue', 'bucket');
        $result = [];
        $buckets = $hourly ? now('Asia/Karachi')->hour + 1 : $days;
        for ($i = 0; $i < $buckets; $i++) {
            $date = $hourly ? $start->copy()->addHours($i) : $start->copy()->addDays($i);
            $key = $date->format($hourly ? 'Y-m-d H' : 'Y-m-d');
            $result[] = ['label' => $date->format($hourly ? 'ga' : 'j M'), 'date' => $date->toIso8601String(), 'value' => $this->money($rows[$key] ?? 0)];
        }

        return $result;
    }

    private function money(mixed $amount): string
    {
        return number_format((float) ($amount ?? 0), 2, '.', '');
    }
}
