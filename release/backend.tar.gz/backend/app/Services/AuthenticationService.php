<?php

namespace App\Services;

use App\Models\User;
use App\Support\ApiException;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class AuthenticationService
{
    public function register(array $attributes, Request $request): User
    {
        $user = DB::transaction(function () use ($attributes): User {
            $user = User::create([
                'name' => $attributes['name'],
                'email' => $attributes['email'],
                'password' => $attributes['password'],
            ]);

            $user->customer()->create();
            $user->assignRole('customer');

            return $user;
        });

        Auth::guard('web')->login($user);
        $request->session()->regenerate();

        return $user;
    }

    public function login(array $credentials, Request $request, bool $admin = false): User
    {
        $valid = Auth::guard('web')->attempt([
            'email' => $credentials['email'],
            'password' => $credentials['password'],
            'is_active' => true,
        ]);

        if (! $valid) {
            throw new ApiException('invalid_credentials', 'The provided credentials are invalid.', 401);
        }

        /** @var User $user */
        $user = Auth::guard('web')->user();

        if ($admin && ! $user->can('admin.access')) {
            $this->logout($request);
            throw new ApiException('invalid_credentials', 'The provided credentials are invalid.', 401);
        }

        $request->session()->regenerate();

        return $user;
    }

    public function logout(Request $request): void
    {
        Auth::guard('web')->logout();
        $request->session()->invalidate();
        $request->session()->regenerateToken();
        Auth::forgetGuards();
    }
}
