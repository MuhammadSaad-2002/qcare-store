<?php

namespace App\Console\Commands;

use App\Models\ProductAttribute;
use App\Models\ProductVariant;
use App\Services\Catalog\PublicationGuard;
use App\Support\ApiException;
use App\Support\PackContents;
use Illuminate\Console\Attributes\Description;
use Illuminate\Console\Attributes\Signature;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;

#[Signature('app:sync-pos-pack-catalog {--publish : Publish complete listings after updating prices and pack details}')]
#[Description('Sync imported POS listings to full-pack selling prices and pack details without changing inventory')]
class SyncPosPackCatalog extends Command
{
    public function handle(PublicationGuard $publicationGuard): int
    {
        if (! config('database.connections.pos_source.database') || ! config('database.connections.pos_source.username')) {
            $this->error('Set POS_SOURCE_DB_DATABASE and POS_SOURCE_DB_USERNAME before syncing.');

            return self::FAILURE;
        }

        $variants = ProductVariant::query()->with('product')->where('sku', 'like', 'POS-%')->get()
            ->filter(fn (ProductVariant $variant): bool => in_array($variant->product?->status, ['draft', 'published'], true));
        $codes = $variants->pluck('sku')->map(fn (string $sku): string => substr($sku, 4))->all();
        $sourceProducts = DB::connection('pos_source')->table('products')->whereIn('code', $codes)
            ->get(['code', 'name', 'sale_price', 'pieces_per_pack', 'is_active', 'restricted_for_sale', 'is_narcotics'])
            ->keyBy('code');
        $packAttribute = ProductAttribute::query()->firstOrCreate(['code' => 'pack_size'], ['name' => 'Pack size', 'sort_order' => 1]);
        $updated = 0;
        $published = 0;
        $missingImages = 0;

        foreach ($variants as $variant) {
            $source = $sourceProducts->get(substr($variant->sku, 4));
            if (! $source || ! $source->is_active || $source->restricted_for_sale || $source->is_narcotics
                || (float) $source->sale_price <= 0 || (int) $source->pieces_per_pack < 1) {
                $this->warn("Skipped {$variant->sku}: the active POS pack or its price is unavailable.");

                continue;
            }

            DB::transaction(function () use ($variant, $source, $packAttribute, $publicationGuard, &$updated, &$published, &$missingImages): void {
                $product = $variant->product;
                $packSize = (int) $source->pieces_per_pack;
                $packContents = PackContents::fromPosName($source->name, $packSize);
                $baseName = preg_replace('/\s*(?:\((?:Pack of )?\d+(?:\s+\w+)?\)|\d+S)\s*$/i', '', $product->name);
                $baseName = preg_replace('/\s*(?:\(\d+\)|\d+S)\s*$/i', '', $baseName);
                $packValue = $packAttribute->values()->firstOrCreate(['value' => $packContents]);
                $previousPackValueIds = $variant->values()->where('product_attribute_id', $packAttribute->id)->pluck('product_attribute_values.id');
                $variant->values()->detach($previousPackValueIds);
                $variant->values()->syncWithoutDetaching([$packValue->id]);

                $product->update([
                    'name' => $baseName,
                    'summary' => "One pack contains {$packContents}. Price shown is for one full pack.",
                    'visibility' => 'public',
                ]);
                $updated++;

                if ($product->status === 'published') {
                    return;
                }

                $variant->update(['regular_price' => $source->sale_price, 'sale_price' => null]);

                if ($product->kind === 'medicine') {
                    $medical = $product->medicalDetails()->firstOrCreate([]);
                    if ($medical->requires_prescription === null && $medical->is_otc === null) {
                        $medical->update(['requires_prescription' => true, 'is_otc' => false]);
                    }
                }

                if (! $this->option('publish')) {
                    return;
                }

                $primaryImage = $product->images()->where('is_primary', true)->first();
                if (! $primaryImage || ! Storage::disk('public')->exists($primaryImage->path)) {
                    $missingImages++;
                    $this->warn("Kept {$variant->sku} as draft: a verified primary image is missing.");

                    return;
                }

                try {
                    $publicationGuard->assertCanPublish($product->fresh());
                } catch (ApiException $exception) {
                    $this->warn("Kept {$variant->sku} as draft: {$exception->getMessage()}");

                    return;
                }

                $product->update(['status' => 'published']);
                $published++;
            });
        }

        $this->info("Synced pack-size attributes for {$updated} POS listings; published {$published}; {$missingImages} still need an image.");
        $this->info('Inventory is unchanged. Use app:sync-inventisys-inventory with a fresh stock snapshot to sync real availability.');

        return self::SUCCESS;
    }
}
