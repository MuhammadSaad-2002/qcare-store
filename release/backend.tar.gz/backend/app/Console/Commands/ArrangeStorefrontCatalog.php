<?php

namespace App\Console\Commands;

use App\Services\Catalog\StorefrontHierarchy;
use Illuminate\Console\Attributes\Description;
use Illuminate\Console\Attributes\Signature;
use Illuminate\Console\Command;
use Throwable;

#[Signature('app:arrange-storefront-catalog {--dry-run : Preview category and product assignments without writing}')]
#[Description('Arrange the reviewed catalog into departments and nested product families')]
class ArrangeStorefrontCatalog extends Command
{
    /**
     * Execute the console command.
     */
    public function handle(StorefrontHierarchy $hierarchy): int
    {
        try {
            $report = $hierarchy->arrange((bool) $this->option('dry-run'));
            $this->info(($this->option('dry-run') ? 'Previewed ' : 'Reviewed ').$report['products_reviewed'].' products; '.count($report['category_changes']).' category changes and '.count($report['product_changes']).' product category assignments.');

            return self::SUCCESS;
        } catch (Throwable $exception) {
            $this->error($exception->getMessage());

            return self::FAILURE;
        }
    }
}
