<?php

namespace App\Console\Commands;

use App\Models\Category;
use App\Models\Product;
use App\Models\ProductAttribute;
use App\Models\ProductVariant;
use App\Support\PackContents;
use Illuminate\Console\Attributes\Description;
use Illuminate\Console\Attributes\Signature;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

#[Signature('app:import-pos-top-sellers {--limit=30 : Maximum eligible products to review and import}')]
#[Description('Import the POS best sellers as unpublished catalog drafts')]
class ImportPosTopSellers extends Command
{
    public function handle(): int
    {
        if (! config('database.connections.pos_source.database') || ! config('database.connections.pos_source.username')) {
            $this->error('Set POS_SOURCE_DB_DATABASE and POS_SOURCE_DB_USERNAME before importing.');

            return self::FAILURE;
        }

        $limit = filter_var($this->option('limit'), FILTER_VALIDATE_INT);
        if ($limit === false || $limit < 1 || $limit > 100) {
            $this->error('The limit must be between 1 and 100.');

            return self::FAILURE;
        }

        $sql = <<<'SQL'
SELECT p.name, p.code, p.sale_price, p.pieces_per_pack,
       c.name AS category_name,
       ROUND(s.sold_qty - COALESCE(r.return_qty, 0), 2) AS net_qty
FROM products p
JOIN (
    SELECT si.product_id, SUM(si.quantity) AS sold_qty
    FROM sale_invoice_items si
    JOIN sale_invoices i ON i.id = si.invoice_id AND i.status = 'posted'
    GROUP BY si.product_id
) s ON s.product_id = p.id
LEFT JOIN (
    SELECT ri.product_id, SUM(ri.quantity) AS return_qty
    FROM sale_return_items ri
    JOIN sale_returns sr ON sr.id = ri.sale_return_id AND sr.status = 'posted'
    GROUP BY ri.product_id
) r ON r.product_id = p.id
LEFT JOIN product_categories c ON c.id = p.category_id
WHERE p.is_active = 1 AND p.restricted_for_sale = 0 AND p.is_narcotics = 0
  AND c.name IN ('MEDICINE', 'SURGICAL', 'EATRY')
  AND s.sold_qty - COALESCE(r.return_qty, 0) > 0
ORDER BY net_qty DESC, p.id
LIMIT ?
SQL;
        $rows = DB::connection('pos_source')->select($sql, [$limit]);
        $categoryNames = ['MEDICINE' => 'Medicines', 'SURGICAL' => 'Medical Supplies', 'EATRY' => 'Food & Snacks'];
        $categoryDescriptions = [
            'MEDICINE' => 'Pharmacy medicines. Product details and prescription status are reviewed before online publication.',
            'SURGICAL' => 'Pharmacy supplies and equipment. Check each product listing for confirmed materials, contents and pack quantity.',
            'EATRY' => 'Packaged food and snacks. Check the pack for ingredients, allergens and best-before details.',
        ];
        $created = 0;
        $skipped = 0;
        $packAttribute = ProductAttribute::firstOrCreate(['code' => 'pack_size'], ['name' => 'Pack size', 'sort_order' => 1]);

        foreach ($rows as $row) {
            $sku = 'POS-'.trim($row->code);
            $slug = Str::slug($row->name);
            if ($slug === '' || ProductVariant::where('sku', $sku)->exists() || Product::withTrashed()->where('slug', $slug)->exists()) {
                $skipped++;

                continue;
            }
            $price = round((float) $row->sale_price, 2);
            if ($price <= 0 || (int) $row->pieces_per_pack < 1) {
                $skipped++;

                continue;
            }
            $kind = $row->category_name === 'MEDICINE' ? 'medicine' : 'general';
            $displayName = preg_replace('/(?<=\d)Mg\b/u', ' mg', Str::title(Str::lower(Str::squish($row->name))));
            $description = match ($row->category_name) {
                'MEDICINE' => "{$displayName} is a pharmacy medicine. Check the package for confirmed ingredients, strength, pack size, directions, warnings and storage instructions. Ask a pharmacist for product-specific guidance.",
                'SURGICAL' => "{$displayName} is a pharmacy supply item. Review the package for the exact contents, materials, quantity and directions before use.",
                default => "{$displayName} is a packaged food item. Read the package for the flavor, ingredients, allergens and best-before information.",
            };

            DB::transaction(function () use ($row, $sku, $slug, $price, $kind, $displayName, $description, $categoryNames, $categoryDescriptions, $packAttribute): void {
                $category = Category::firstOrCreate(
                    ['slug' => Str::slug($categoryNames[$row->category_name])],
                    ['name' => $categoryNames[$row->category_name], 'description' => $categoryDescriptions[$row->category_name], 'is_active' => true]
                );
                $product = Product::create([
                    'name' => $displayName,
                    'slug' => $slug,
                    'kind' => $kind,
                    'status' => 'draft',
                    'visibility' => 'hidden',
                    'summary' => 'One pack contains '.PackContents::fromPosName($row->name, (int) $row->pieces_per_pack).'. Price shown is for one full pack.',
                    'description' => $description,
                ]);
                $product->categories()->attach($category);
                if ($kind === 'medicine') {
                    $product->medicalDetails()->create();
                }
                $variant = $product->variants()->create([
                    'sku' => $sku,
                    'regular_price' => $price,
                    'currency_code' => 'PKR',
                    'status' => 'active',
                ]);
                $packValue = $packAttribute->values()->firstOrCreate(['value' => PackContents::fromPosName($row->name, (int) $row->pieces_per_pack)]);
                $variant->values()->attach($packValue);
                $variant->inventory()->create(['quantity_on_hand' => 0, 'tracks_stock' => true, 'allows_backorder' => false]);
            });
            $created++;
        }

        $this->info("Created {$created} draft products; skipped {$skipped} existing or invalid products. No stock was imported.");

        return self::SUCCESS;
    }
}
