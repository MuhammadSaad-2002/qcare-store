<?php

namespace App\Console\Commands;

use App\Models\Brand;
use App\Models\Category;
use App\Models\Product;
use App\Models\ProductAttribute;
use App\Models\ProductImage;
use App\Models\ProductVariant;
use Illuminate\Console\Attributes\Description;
use Illuminate\Console\Attributes\Signature;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;
use RuntimeException;
use Throwable;

#[Signature('app:import-inventisys-batch {manifest : Path to a reviewed JSON batch} {--limit=25 : Batch size, maximum 50} {--offset=0 : First manifest row} {--dry-run : Validate and preview without writing}')]
#[Description('Import reviewed InventiSys products and watermark-free pack images as hidden drafts')]
class ImportInventisysBatch extends Command
{
    private const CATEGORIES = [
        'vitamins-supplements' => ['Vitamins & Supplements', null],
        'multivitamins' => ['Multivitamins', 'vitamins-supplements'],
        'vitamins-minerals' => ['Vitamins & Minerals', 'vitamins-supplements'],
        'beauty-supplements' => ['Beauty Supplements', 'vitamins-supplements'],
        'omega-oils' => ['Omega & Essential Oils', 'vitamins-supplements'],
        'childrens-supplements' => ['Children’s Supplements', 'vitamins-supplements'],
        'sports-nutrition' => ['Sports Nutrition', 'vitamins-supplements'],
        'formula-nutrition' => ['Formula Milk & Nutrition', null],
        'baby-formulas' => ['Baby Formulas', 'formula-nutrition'],
        'growing-up-nutrition' => ['Growing-up Nutrition', 'formula-nutrition'],
        'adult-senior-nutrition' => ['Adult & Senior Nutrition', 'formula-nutrition'],
        'medicines' => ['Medicines', null],
        'medical-supplies' => ['Medical Supplies', null],
        'medical-devices' => ['Medical Devices', null],
        'food-snacks' => ['Food & Snacks', null],
        'skin-care' => ['Skin Care', null],
        'personal-care' => ['Personal Care', null],
        'baby-mother-care' => ['Baby & Mother Care', null],
        'oral-care' => ['Oral Care', null],
        'hair-care' => ['Hair Care', null],
        'first-aid' => ['First Aid', null],
        'herbal-care' => ['Herbal Care', null],
        'homeopathic-products' => ['Homeopathic Products', null],
    ];

    public function handle(): int
    {
        $writtenFiles = [];
        try {
            $path = realpath((string) $this->argument('manifest'));
            if (! $path || ! is_file($path)) {
                throw new RuntimeException('The manifest file does not exist.');
            }
            $manifest = json_decode(file_get_contents($path), true, 512, JSON_THROW_ON_ERROR);
            $limit = filter_var($this->option('limit'), FILTER_VALIDATE_INT);
            $offset = filter_var($this->option('offset'), FILTER_VALIDATE_INT);
            if ($limit === false || $limit < 1 || $limit > 50 || $offset === false || $offset < 0 || ! is_array($manifest['products'] ?? null)) {
                throw new RuntimeException('Use a valid products manifest, a limit of 1–50 and a non-negative offset.');
            }
            $rows = array_slice($manifest['products'], $offset, $limit);
            if ($rows === []) {
                throw new RuntimeException('This batch contains no products.');
            }
            $seenCodes = [];
            foreach ($rows as &$row) {
                $this->validateRow($row, dirname($path));
                if (isset($seenCodes[$row['source_code']])) {
                    throw new RuntimeException('Duplicate source code in the batch: '.$row['source_code']);
                }
                $seenCodes[$row['source_code']] = true;
            }
            unset($row);
            $created = [];
            $skipped = [];
            if (! $this->option('dry-run')) {
                DB::transaction(function () use ($rows, &$created, &$skipped, &$writtenFiles): void {
                    foreach ($rows as $row) {
                        $sku = 'POS-'.$row['source_code'];
                        $slug = Str::slug($row['name']);
                        if (ProductVariant::where('sku', $sku)->exists() || Product::withTrashed()->where('slug', $slug)->exists()) {
                            $skipped[] = $sku;

                            continue;
                        }
                        $brand = Brand::firstOrCreate(['slug' => Str::slug($row['brand'])], ['name' => $row['brand'], 'is_active' => true]);
                        $product = Product::create([
                            'name' => $row['name'], 'slug' => $slug, 'brand_id' => $brand->id,
                            'kind' => $row['kind'], 'status' => 'draft', 'visibility' => 'hidden',
                            'summary' => 'Pack size: '.$row['pack_size'].'. Price shown is for one full pack.',
                            'description' => $row['name'].'. Check the pack label for ingredients, directions and storage instructions. Contact the pharmacy for product information.',
                        ]);
                        $categoryIds = array_map(fn (string $category): int => $this->category($category)->id, $row['categories']);
                        $product->categories()->sync($categoryIds);
                        if ($row['kind'] === 'medicine') {
                            $product->medicalDetails()->create();
                        }
                        $variant = $product->variants()->create(['sku' => $sku, 'regular_price' => $row['regular_price'], 'currency_code' => 'PKR', 'status' => 'active']);
                        $attribute = ProductAttribute::firstOrCreate(['code' => 'pack_size'], ['name' => 'Pack size', 'sort_order' => 1]);
                        $value = $attribute->values()->firstOrCreate(['value' => $row['pack_size']]);
                        $variant->values()->attach($value);
                        $variant->inventory()->create(['quantity_on_hand' => 0, 'tracks_stock' => true, 'allows_backorder' => false]);
                        $imagePath = 'products/inventisys/'.Str::slug($sku).'-'.substr($row['image']['sha256'], 0, 16).'.'.$row['_image_extension'];
                        if (! Storage::disk('public')->exists($imagePath)) {
                            $writtenFiles[] = $imagePath;
                            if (! Storage::disk('public')->put($imagePath, file_get_contents($row['_image_path']))) {
                                throw new RuntimeException('The product image could not be stored.');
                            }
                        }
                        $product->images()->create(['path' => $imagePath, 'alt_text' => $row['name'].' pack', 'is_primary' => true, 'sort_order' => 0]);
                        $created[] = ['sku' => $sku, 'slug' => $slug, 'public_id' => $product->public_id];
                    }
                });
                Storage::disk('local')->put('catalog-imports/'.now()->format('Ymd-His').'-'.Str::uuid().'.json', json_encode([
                    'batch' => $manifest['batch'] ?? null, 'imported_at' => now()->toIso8601String(),
                    'manifest_sha256' => hash_file('sha256', $path), 'manifest' => $manifest,
                    'created' => $created, 'skipped' => $skipped,
                ], JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR));
            }
            $this->info($this->option('dry-run') ? 'Validated '.count($rows).' reviewed products. No changes made.' : 'Created '.count($created).' hidden drafts; skipped '.count($skipped).' existing listings. Stock remains zero.');

            return self::SUCCESS;
        } catch (Throwable $exception) {
            foreach ($writtenFiles as $file) {
                if (! DB::transactionLevel()) {
                    // Rolled-back records have no surviving image references.
                    if (! ProductImage::where('path', $file)->exists()) {
                        Storage::disk('public')->delete($file);
                    }
                }
            }
            $this->error($exception->getMessage());

            return self::FAILURE;
        }
    }

    /** @param array<string, mixed> $row */
    private function validateRow(array &$row, string $directory): void
    {
        if (($row['review_status'] ?? null) !== 'approved'
            || ($row['image']['watermark_review'] ?? null) !== 'passed'
            || ($row['image']['pack_match_review'] ?? null) !== 'passed') {
            throw new RuntimeException('Each product requires approved product, watermark and exact-pack reviews.');
        }
        if (($row['source_active'] ?? false) !== true || ($row['source_restricted'] ?? true) !== false || ($row['source_narcotics'] ?? true) !== false) {
            throw new RuntimeException('Inactive, restricted or narcotic source products cannot be imported.');
        }
        foreach (['source_id', 'source_code', 'source_name', 'name', 'brand', 'pack_size'] as $field) {
            if (! is_string($row[$field] ?? null) || trim($row[$field]) === '' || mb_strlen($row[$field]) > ($field === 'source_code' ? 96 : 255)) {
                throw new RuntimeException('Invalid or missing product field: '.$field);
            }
        }
        if (! in_array($row['kind'] ?? null, ['general', 'medicine'], true) || ! preg_match('/^\d{1,10}(?:\.\d{1,2})?$/', (string) ($row['regular_price'] ?? '')) || (float) $row['regular_price'] <= 0) {
            throw new RuntimeException('A valid product kind and positive full-pack price are required.');
        }
        if (! is_array($row['categories'] ?? null) || $row['categories'] === [] || count(array_diff($row['categories'], array_keys(self::CATEGORIES)))) {
            throw new RuntimeException('Use supported e-commerce categories.');
        }
        foreach (['url', 'source_page'] as $field) {
            if (! filter_var($row['image'][$field] ?? null, FILTER_VALIDATE_URL) || parse_url($row['image'][$field], PHP_URL_SCHEME) !== 'https') {
                throw new RuntimeException('Image source URLs must use HTTPS.');
            }
        }
        $image = realpath($directory.DIRECTORY_SEPARATOR.($row['image']['file'] ?? ''));
        if (! $image || ! str_starts_with($image, $directory.DIRECTORY_SEPARATOR) || ! is_file($image) || filesize($image) > 2 * 1024 * 1024) {
            throw new RuntimeException('Image files must be inside the batch directory and no larger than 2 MB.');
        }
        $dimensions = @getimagesize($image);
        $extension = match ($dimensions[2] ?? null) {
            IMAGETYPE_JPEG => 'jpg', IMAGETYPE_PNG => 'png', IMAGETYPE_WEBP => 'webp', default => null
        };
        if (! $extension || $dimensions[0] < 300 || $dimensions[1] < 300 || ! hash_equals(hash_file('sha256', $image), $row['image']['sha256'] ?? '')) {
            throw new RuntimeException('The image must be a reviewed JPG, PNG or WebP of at least 300 × 300 pixels with a matching checksum.');
        }
        $row['_image_path'] = $image;
        $row['_image_extension'] = $extension;
    }

    private function category(string $slug): Category
    {
        [$name, $parent] = self::CATEGORIES[$slug];

        return Category::firstOrCreate(['slug' => $slug], ['name' => $name, 'parent_id' => $parent ? $this->category($parent)->id : null, 'is_active' => true]);
    }
}
