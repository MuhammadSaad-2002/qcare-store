<?php

namespace App\Console\Commands;

use App\Models\Product;
use App\Support\ProductTags;
use Illuminate\Console\Attributes\Description;
use Illuminate\Console\Attributes\Signature;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Str;
use RuntimeException;
use Throwable;

#[Signature('app:import-product-tags {manifest : Reviewed product tag JSON} {--dry-run : Validate without changing product tags}')]
#[Description('Apply reviewed health, use and product-type tags by SKU, preserving existing tags')]
class ImportProductTags extends Command
{
    public function handle(): int
    {
        try {
            $path = realpath((string) $this->argument('manifest'));
            if (! $path || ! is_file($path) || filesize($path) > 2 * 1024 * 1024) {
                throw new RuntimeException('Use an existing tag manifest of at most 2 MB.');
            }
            $manifest = json_decode(file_get_contents($path), true, 512, JSON_THROW_ON_ERROR);
            $rows = $manifest['products'] ?? null;
            if (! is_array($rows) || $rows === [] || count($rows) > 1000) {
                throw new RuntimeException('Provide 1–1000 reviewed products.');
            }
            $seen = [];
            foreach ($rows as $row) {
                Validator::make($row, [
                    'sku' => ['required', 'string', 'max:100'], 'name' => ['required', 'string', 'max:255'],
                    'review_status' => ['required', 'in:approved'],
                    'sources' => ['required', 'array', 'min:1'], 'sources.*' => ['required', 'url:https'],
                    ...ProductTags::rules(),
                ])->validate();
                foreach (ProductTags::FIELDS as $field) {
                    if (! array_key_exists($field, $row)) {
                        throw new RuntimeException('Review all three tag groups for each product.');
                    }
                }
                if (isset($seen[$row['sku']])) {
                    throw new RuntimeException('Duplicate SKU in tag manifest: '.$row['sku']);
                }
                $seen[$row['sku']] = true;
            }
            $changes = DB::transaction(function () use ($rows): array {
                $products = Product::whereHas('variants', fn ($query) => $query->whereIn('sku', array_column($rows, 'sku')))
                    ->with('variants:id,product_id,sku')->lockForUpdate()->get();
                $bySku = [];
                foreach ($products as $product) {
                    foreach ($product->variants as $variant) {
                        $bySku[$variant->sku] = $product;
                    }
                }
                $changes = [];
                foreach ($rows as $row) {
                    $product = $bySku[$row['sku']] ?? null;
                    if (! $product || $product->name !== $row['name']) {
                        throw new RuntimeException('Missing or changed product identity: '.$row['sku']);
                    }
                    $before = $after = [];
                    foreach (ProductTags::FIELDS as $field) {
                        $before[$field] = $product->{$field} ?? [];
                        $after[$field] = ProductTags::merge($before[$field], $row[$field]);
                        if (count($after[$field]) > 20) {
                            throw new RuntimeException('Merged group exceeds 20 tags: '.$row['sku']);
                        }
                    }
                    if ($before === $after) {
                        continue;
                    }
                    if (! $this->option('dry-run')) {
                        $product->update($after);
                    }
                    $changes[] = ['sku' => $row['sku'], 'product_id' => $product->id, 'before' => $before, 'after' => $after];
                }

                return $changes;
            });
            if (! $this->option('dry-run') && $changes !== []) {
                Storage::disk('local')->put('catalog-tags/'.now()->format('Ymd-His').'-'.Str::uuid().'.json', json_encode([
                    'applied_at' => now()->toIso8601String(), 'manifest_sha256' => hash_file('sha256', $path),
                    'manifest' => $manifest, 'changes' => $changes,
                ], JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR));
            }
            $this->info(($this->option('dry-run') ? 'Validated' : 'Reviewed').' '.count($rows).' products; '.count($changes).($this->option('dry-run') ? ' would receive tags.' : ' received tags.'));

            return self::SUCCESS;
        } catch (Throwable $exception) {
            $this->error($exception->getMessage());

            return self::FAILURE;
        }
    }
}
