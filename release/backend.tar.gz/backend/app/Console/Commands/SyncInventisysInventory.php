<?php

namespace App\Console\Commands;

use App\Models\Inventory;
use App\Models\ProductVariant;
use Carbon\CarbonImmutable;
use Illuminate\Console\Attributes\Description;
use Illuminate\Console\Attributes\Signature;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;
use RuntimeException;
use Throwable;

#[Signature('app:sync-inventisys-inventory {snapshot : Fresh complete stock snapshot from scripts/export-inventisys-stock.mjs} {--dry-run : Preview without changing inventory}')]
#[Description('Replace matching website stock with InventiSys available complete packs and record inventory movements')]
class SyncInventisysInventory extends Command
{
    public function handle(): int
    {
        try {
            $path = realpath((string) $this->argument('snapshot'));
            if (! $path || ! is_file($path)) {
                throw new RuntimeException('The stock snapshot file does not exist.');
            }
            $snapshot = json_decode(file_get_contents($path), true, 512, JSON_THROW_ON_ERROR);
            $source = $this->validateSnapshot($snapshot);
            $dryRun = (bool) $this->option('dry-run');
            $report = DB::transaction(function () use ($source, $snapshot, $dryRun): array {
                $variants = ProductVariant::query()->where('sku', 'like', 'POS-%')
                    ->whereHas('product', fn ($query) => $query->whereIn('status', ['draft', 'published']))
                    ->with('product')->orderBy('id')->get();
                $report = [];
                foreach ($variants as $variant) {
                    $code = substr($variant->sku, 4);
                    $row = $source[$code] ?? null;
                    $eligible = $row && $row['is_active'] && ! $row['restricted_for_sale'] && ! $row['is_narcotics'];
                    $after = $eligible ? $row['available_packs'] : 0;
                    $inventory = Inventory::query()->where('product_variant_id', $variant->id)->lockForUpdate()->first();
                    $before = (int) ($inventory?->quantity_on_hand ?? 0);
                    $delta = $after - $before;
                    if ($delta < -2147483648 || $delta > 2147483647) {
                        throw new RuntimeException('Inventory movement exceeds the supported range: '.$variant->sku);
                    }
                    $changed = ! $inventory || $before !== $after || ! $inventory->tracks_stock || $inventory->allows_backorder;
                    $status = ! $row ? 'source_missing' : (! $eligible ? 'source_ineligible' : 'matched');
                    if ($changed && ! $dryRun) {
                        if (! $inventory) {
                            $inventory = $variant->inventory()->create(['quantity_on_hand' => 0, 'tracks_stock' => true, 'allows_backorder' => false]);
                        }
                        $inventory->update(['quantity_on_hand' => $after, 'tracks_stock' => true, 'allows_backorder' => false]);
                        $sourceDescription = $eligible ? "{$row['available_units']} available units / {$row['pieces_per_pack']} per pack" : $status;
                        $variant->movements()->create([
                            'delta' => $delta, 'quantity_before' => $before, 'quantity_after' => $after,
                            'reason' => Str::limit("InventiSys stock sync: {$snapshot['branch']['name']}; {$code}; {$sourceDescription}; snapshot {$snapshot['captured_at']}.", 500, ''),
                        ]);
                    }
                    $report[] = ['sku' => $variant->sku, 'name' => $variant->product->name, 'before_packs' => $before, 'after_packs' => $after,
                        'changed' => $changed, 'status' => $status, 'source_units' => $row['available_units'] ?? null, 'pieces_per_pack' => $row['pieces_per_pack'] ?? null];
                }

                return $report;
            });
            $changed = count(array_filter($report, fn (array $row): bool => $row['changed']));
            $missing = count(array_filter($report, fn (array $row): bool => $row['status'] === 'source_missing'));
            if (! $dryRun) {
                Storage::disk('local')->put('inventory-syncs/'.now()->format('Ymd-His').'-'.Str::uuid().'.json', json_encode([
                    'source' => 'InventiSys', 'synced_at' => now()->toIso8601String(), 'branch' => $snapshot['branch'],
                    'snapshot_sha256' => hash_file('sha256', $path), 'source_snapshot' => $snapshot, 'products' => $report,
                ], JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR));
            }
            $this->info(($dryRun ? 'Previewed ' : 'Synced ').count($report)." website variants; {$changed} ".($dryRun ? 'would change' : 'changed')."; {$missing} missing source codes.");
            if ($missing > 0) {
                $this->warn('Unmatched source codes use zero stock until their identity is resolved.');
            }
            $this->info('Stock is measured in complete packs. Source prices and website product details were not changed.');

            return self::SUCCESS;
        } catch (Throwable $exception) {
            $this->error($exception->getMessage());

            return self::FAILURE;
        }
    }

    /** @return array<string, array<string, mixed>> */
    private function validateSnapshot(array $snapshot): array
    {
        if (($snapshot['schema_version'] ?? null) !== 1 || ($snapshot['source'] ?? null) !== 'InventiSys'
            || ($snapshot['website_stock_unit'] ?? null) !== 'complete_packs' || ($snapshot['complete_catalog'] ?? false) !== true
            || ! is_array($snapshot['products'] ?? null) || $snapshot['products'] === []
            || ($snapshot['product_count'] ?? null) !== count($snapshot['products'])
            || ! is_string($snapshot['branch']['id'] ?? null) || trim($snapshot['branch']['id']) === ''
            || ! is_string($snapshot['branch']['name'] ?? null) || trim($snapshot['branch']['name']) === '') {
            throw new RuntimeException('Use a complete InventiSys stock snapshot with a selected branch and complete-pack units.');
        }
        if (! is_string($snapshot['captured_at'] ?? null) || ! preg_match('/^\d{4}-\d{2}-\d{2}T/', $snapshot['captured_at'])) {
            throw new RuntimeException('The snapshot timestamp is invalid.');
        }
        $captured = CarbonImmutable::parse($snapshot['captured_at']);
        if ($captured->isBefore(now()->subMinutes(15)) || $captured->isAfter(now()->addMinutes(2))) {
            throw new RuntimeException('Export a fresh stock snapshot; this snapshot is older than 15 minutes or dated in the future.');
        }
        $source = [];
        foreach ($snapshot['products'] as $row) {
            if (! is_array($row) || ! is_string($row['code'] ?? null) || trim($row['code']) === '' || strlen($row['code']) > 96) {
                throw new RuntimeException('Every stock row needs a valid product code.');
            }
            if (isset($source[$row['code']])) {
                throw new RuntimeException('Duplicate source product code: '.$row['code']);
            }
            foreach (['is_active', 'restricted_for_sale', 'is_narcotics'] as $field) {
                if (! is_bool($row[$field] ?? null)) {
                    throw new RuntimeException('Source eligibility flags must be explicit booleans.');
                }
            }
            foreach (['physical_units', 'reserved_units', 'available_units'] as $field) {
                if (! is_string($row[$field] ?? null) || ! preg_match('/^\d{1,12}(?:\.\d{1,4})?$/', $row[$field])) {
                    throw new RuntimeException('Stock quantities must be non-negative decimal unit quantities.');
                }
            }
            if (! is_int($row['pieces_per_pack'] ?? null) || $row['pieces_per_pack'] < 1
                || ! is_int($row['available_packs'] ?? null) || $row['available_packs'] < 0 || $row['available_packs'] > 4294967295) {
                throw new RuntimeException('Pack sizes and available pack counts must be valid integers.');
            }
            $calculatedPacks = intdiv((int) explode('.', $row['available_units'])[0], $row['pieces_per_pack']);
            $calculatedUnits = max(0, (float) $row['physical_units'] - (float) $row['reserved_units']);
            if ($calculatedPacks !== $row['available_packs'] || abs($calculatedUnits - (float) $row['available_units']) > 0.0001) {
                throw new RuntimeException('Reserved units or full-pack conversion are inconsistent: '.$row['code']);
            }
            $source[$row['code']] = $row;
        }

        return $source;
    }
}
